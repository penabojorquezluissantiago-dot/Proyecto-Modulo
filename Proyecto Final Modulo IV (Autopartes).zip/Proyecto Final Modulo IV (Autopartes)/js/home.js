document.addEventListener("DOMContentLoaded", async () => {
    const container = document.getElementById("featured-products");
    if (!container) return;
    try {
        const { products } = await MotorCrew.request("/api/products");
        container.replaceChildren();
        if (products.length === 0) {
            const message = document.createElement("p");
            message.className = "store-message";
            message.textContent = "Aún no hay productos publicados. ¿Tienes algo para vender?";
            container.append(message);
            return;
        }
        products.slice(0, 3).forEach(product => container.append(MotorCrew.productCard(product)));
    } catch (error) {
        container.textContent = error.message;
    }
});
