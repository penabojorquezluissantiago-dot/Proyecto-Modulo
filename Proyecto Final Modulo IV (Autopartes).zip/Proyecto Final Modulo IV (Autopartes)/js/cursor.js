(() => {
    const lerp = (start, end, amount) => start + (end - start) * amount;
    const supportsCursor = window.matchMedia(
        '(min-width: 860px) and (hover: hover) and (pointer: fine)'
    ).matches;

    const cursorElement = document.querySelector('.cursor');

    if (supportsCursor && cursorElement) {
        const dot = cursorElement.querySelector('.cursor__inner--dot');
        const circle = cursorElement.querySelector('.cursor__inner--circle');

        if (!dot || !circle) {
            throw new Error('No se encontraron las partes del cursor personalizado.');
        }

        const dotBounds = dot.getBoundingClientRect();
        const circleBounds = circle.getBoundingClientRect();
        const mouse = { x: 0, y: 0 };
        const last = {
            dot: { x: 0, y: 0 },
            circle: { x: 0, y: 0 }
        };
        let scale = 1;
        let lastScale = 1;
        let hasPointerPosition = false;
        let isDragging = false;

        window.addEventListener('mousemove', event => {
            mouse.x = event.clientX;
            mouse.y = event.clientY;
            hasPointerPosition = true;
        }, { passive: true });

        function renderCursor() {
            last.dot.x = lerp(last.dot.x, mouse.x - dotBounds.width / 2, 1);
            last.dot.y = lerp(last.dot.y, mouse.y - dotBounds.height / 2, 1);
            last.circle.x = lerp(last.circle.x, mouse.x - circleBounds.width / 2, 0.15);
            last.circle.y = lerp(last.circle.y, mouse.y - circleBounds.height / 2, 0.15);
            lastScale = lerp(lastScale, scale, 0.15);

            dot.style.transform = `translateX(${last.dot.x}px) translateY(${last.dot.y}px)`;
            circle.style.transform =
                `translateX(${last.circle.x}px) translateY(${last.circle.y}px) scale(${lastScale})`;

            if (hasPointerPosition && !cursorElement.classList.contains('is-visible')) {
                cursorElement.classList.add('is-visible');
                document.documentElement.classList.add('has-custom-cursor');
            }

            requestAnimationFrame(renderCursor);
        }

        const hoverSelector = 'a, button, .slide-card, .info-card, .slogan-visual';
        document.addEventListener('mouseover', event => {
            if (event.target instanceof Element && event.target.closest(hoverSelector)) {
                scale = 1.5;
            }
        });

        document.addEventListener('mouseout', event => {
            const entered = event.relatedTarget instanceof Element &&
                event.relatedTarget.closest(hoverSelector);

            if (event.target instanceof Element &&
                event.target.closest(hoverSelector) && !entered) {
                scale = 1;
            }
        });

        document.addEventListener('pointerdown', event => {
            if (event.button === 0 &&
                event.target instanceof Element &&
                event.target.closest('#app, .gallery-intro')) {
                isDragging = true;
                scale = 1.5;
            }
        });

        window.addEventListener('pointerup', () => {
            if (isDragging) {
                isDragging = false;
                scale = 1;
            }
        });

        window.addEventListener('pointercancel', () => {
            if (isDragging) {
                isDragging = false;
                scale = 1;
            }
        });

        renderCursor();
    }

    const vertexShaderSource = `
        precision mediump float;
        attribute vec2 a_position;
        uniform vec4 u_rect;
        uniform vec2 u_canvasResolution;
        uniform vec2 u_viewportResolution;
        uniform vec2 u_groupOffset;
        varying vec2 vUv;
        varying vec2 vScreenUv;
        varying vec2 vLocalPixel;

        void main() {
            vec2 position = u_rect.xy + a_position * u_rect.zw;
            vec2 screenPosition = position + u_groupOffset;
            gl_Position = vec4(
                position.x / u_canvasResolution.x * 2.0 - 1.0,
                1.0 - position.y / u_canvasResolution.y * 2.0,
                0.0,
                1.0
            );
            vUv = vec2(a_position.x, 1.0 - a_position.y);
            vLocalPixel = a_position * u_rect.zw;
            vScreenUv = vec2(
                screenPosition.x / u_viewportResolution.x,
                1.0 - screenPosition.y / u_viewportResolution.y
            );
        }
    `;

    const fragmentShaderSource = `
        precision mediump float;
        uniform vec2 u_resolution;
        uniform sampler2D u_texture;
        uniform vec2 u_textureFactor;
        uniform vec2 u_rgbPosition;
        uniform vec2 u_rgbVelocity;
        uniform vec2 u_rectSize;
        uniform float u_cornerRadius;
        varying vec2 vUv;
        varying vec2 vScreenUv;
        varying vec2 vLocalPixel;

        vec2 centeredAspectRatio(vec2 uv, vec2 factor) {
            return uv * factor - factor / 2.0 + 0.5;
        }

        void main() {
            if (u_cornerRadius > 0.0) {
                vec2 corner = clamp(
                    vLocalPixel,
                    vec2(u_cornerRadius),
                    u_rectSize - vec2(u_cornerRadius)
                );
                if (distance(vLocalPixel, corner) > u_cornerRadius) discard;
            }

            vec2 normalizedRgbPos = u_rgbPosition / u_resolution;
            normalizedRgbPos.y = 1.0 - normalizedRgbPos.y;

            vec2 velocity = u_rgbVelocity;
            float distanceToCursor = distance(
                normalizedRgbPos + velocity / u_resolution,
                vScreenUv
            );
            float ratio = clamp(1.0 - distanceToCursor * 5.0, 0.0, 1.0);
            vec2 uv = vUv;

            uv.x -= sin(uv.y) * ratio / 100.0 * (velocity.x + velocity.y) / 7.0;
            uv.y -= sin(uv.x) * ratio / 100.0 * (velocity.x + velocity.y) / 7.0;
            float red = texture2D(u_texture, centeredAspectRatio(uv, u_textureFactor)).r;

            uv.x -= sin(uv.y) * ratio / 150.0 * (velocity.x + velocity.y) / 7.0;
            uv.y -= sin(uv.x) * ratio / 150.0 * (velocity.x + velocity.y) / 7.0;
            float green = texture2D(u_texture, centeredAspectRatio(uv, u_textureFactor)).g;

            uv.x -= sin(uv.y) * ratio / 300.0 * (velocity.x + velocity.y) / 7.0;
            uv.y -= sin(uv.x) * ratio / 300.0 * (velocity.x + velocity.y) / 7.0;
            vec4 source = texture2D(u_texture, centeredAspectRatio(vUv, u_textureFactor));
            float blue = texture2D(u_texture, centeredAspectRatio(uv, u_textureFactor)).b;

            gl_FragColor = vec4(red, green, blue, source.a);
        }
    `;

    class RgbEffect {
        constructor(canvas, container) {
            this.canvas = canvas;
            this.container = container;
            this.gl = canvas.getContext('webgl', {
                alpha: true,
                antialias: false,
                premultipliedAlpha: false
            });
            this.sources = [];
            this.position = { x: 0, y: 0 };
            this.previousPosition = { x: 0, y: 0 };
            this.targetPosition = { x: 0, y: 0 };
            this.pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);

            if (!this.gl) {
                throw new Error('WebGL no está disponible en este navegador.');
            }

            this.initializeProgram();
            this.buffer = this.gl.createBuffer();
            this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.buffer);
            this.gl.bufferData(
                this.gl.ARRAY_BUFFER,
                new Float32Array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1]),
                this.gl.STATIC_DRAW
            );
            this.gl.useProgram(this.program);
            this.gl.enableVertexAttribArray(this.attributes.position);
            this.gl.vertexAttribPointer(this.attributes.position, 2, this.gl.FLOAT, false, 0, 0);

            window.addEventListener('mousemove', event => {
                this.targetPosition.x = event.clientX;
                this.targetPosition.y = event.clientY;
            }, { passive: true });

            window.addEventListener('resize', () => this.resize());
            this.resize();
            this.render();
        }

        compileShader(type, source) {
            const shader = this.gl.createShader(type);
            this.gl.shaderSource(shader, source);
            this.gl.compileShader(shader);

            if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) {
                const message = this.gl.getShaderInfoLog(shader);
                this.gl.deleteShader(shader);
                throw new Error(message || 'No se pudo compilar el shader RGB.');
            }

            return shader;
        }

        initializeProgram() {
            const vertex = this.compileShader(this.gl.VERTEX_SHADER, vertexShaderSource);
            const fragment = this.compileShader(this.gl.FRAGMENT_SHADER, fragmentShaderSource);
            const program = this.gl.createProgram();

            this.gl.attachShader(program, vertex);
            this.gl.attachShader(program, fragment);
            this.gl.linkProgram(program);

            if (!this.gl.getProgramParameter(program, this.gl.LINK_STATUS)) {
                throw new Error(this.gl.getProgramInfoLog(program) || 'No se pudo enlazar el shader RGB.');
            }

            this.program = program;
            this.attributes = {
                position: this.gl.getAttribLocation(program, 'a_position')
            };
            this.uniforms = {
                rect: this.gl.getUniformLocation(program, 'u_rect'),
                canvasResolution: this.gl.getUniformLocation(program, 'u_canvasResolution'),
                viewportResolution: this.gl.getUniformLocation(program, 'u_viewportResolution'),
                resolution: this.gl.getUniformLocation(program, 'u_resolution'),
                groupOffset: this.gl.getUniformLocation(program, 'u_groupOffset'),
                textureFactor: this.gl.getUniformLocation(program, 'u_textureFactor'),
                rgbPosition: this.gl.getUniformLocation(program, 'u_rgbPosition'),
                rgbVelocity: this.gl.getUniformLocation(program, 'u_rgbVelocity'),
                rectSize: this.gl.getUniformLocation(program, 'u_rectSize'),
                cornerRadius: this.gl.getUniformLocation(program, 'u_cornerRadius'),
                texture: this.gl.getUniformLocation(program, 'u_texture')
            };

            this.gl.useProgram(program);
            this.gl.enable(this.gl.BLEND);
            this.gl.blendFunc(this.gl.SRC_ALPHA, this.gl.ONE_MINUS_SRC_ALPHA);
        }

        addSource(element, dynamic = false) {
            const texture = this.gl.createTexture();
            this.gl.bindTexture(this.gl.TEXTURE_2D, texture);
            this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR);
            this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MAG_FILTER, this.gl.LINEAR);
            this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_S, this.gl.CLAMP_TO_EDGE);
            this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_T, this.gl.CLAMP_TO_EDGE);

            const source = {
                element,
                texture,
                dynamic,
                ready: false,
                failed: false,
                width: 0,
                height: 0,
                cornerRadius: parseFloat(getComputedStyle(element.parentElement).borderTopLeftRadius) || 0
            };
            this.sources.push(source);

            if (dynamic) {
                return source;
            }

            const image = new Image();
            image.crossOrigin = 'anonymous';
            image.addEventListener('load', () => {
                source.width = image.naturalWidth;
                source.height = image.naturalHeight;
                if (this.upload(source, image)) {
                    element.style.visibility = 'hidden';
                }
            });
            image.addEventListener('error', () => {
                source.failed = true;
                console.error(`No se pudo cargar la imagen para el efecto RGB: ${element.currentSrc || element.src}`);
            });
            image.src = element.currentSrc || element.src;
            return source;
        }

        upload(source, element) {
            const gl = this.gl;
            gl.bindTexture(gl.TEXTURE_2D, source.texture);
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

            try {
                gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, element);
            } catch (error) {
                source.failed = true;
                console.error('No se pudo preparar una textura para el efecto RGB.', error);
                return false;
            }

            source.width = element.videoWidth || element.naturalWidth || element.width;
            source.height = element.videoHeight || element.naturalHeight || element.height;
            source.ready = source.width > 0 && source.height > 0;
            return source.ready;
        }

        resize() {
            const bounds = this.container.getBoundingClientRect();
            const width = Math.max(1, Math.round(bounds.width));
            const height = Math.max(1, Math.round(bounds.height));
            const renderWidth = Math.round(width * this.pixelRatio);
            const renderHeight = Math.round(height * this.pixelRatio);

            if (this.canvas.width !== renderWidth || this.canvas.height !== renderHeight) {
                this.canvas.width = renderWidth;
                this.canvas.height = renderHeight;
                this.gl.viewport(0, 0, renderWidth, renderHeight);
            }
        }

        textureFactor(source, bounds) {
            const rectRatio = bounds.width / bounds.height;
            const imageRatio = source.width / source.height;

            if (rectRatio > imageRatio) {
                return [1, imageRatio / rectRatio];
            }

            return [rectRatio / imageRatio, 1];
        }

        render() {
            const gl = this.gl;
            const groupBounds = this.container.getBoundingClientRect();
            const width = Math.max(1, groupBounds.width);
            const height = Math.max(1, groupBounds.height);
            const velocityX = this.position.x - this.previousPosition.x;
            const velocityY = this.position.y - this.previousPosition.y;

            this.position.x = lerp(this.position.x, this.targetPosition.x, 0.15);
            this.position.y = lerp(this.position.y, this.targetPosition.y, 0.15);

            if (this.canvas.width !== Math.round(width * this.pixelRatio) ||
                this.canvas.height !== Math.round(height * this.pixelRatio)) {
                this.resize();
            }

            gl.viewport(0, 0, this.canvas.width, this.canvas.height);
            gl.clearColor(0, 0, 0, 0);
            gl.clear(gl.COLOR_BUFFER_BIT);
            gl.useProgram(this.program);
            gl.uniform2f(this.uniforms.canvasResolution, width, height);
            gl.uniform2f(this.uniforms.viewportResolution, window.innerWidth, window.innerHeight);
            gl.uniform2f(this.uniforms.resolution, window.innerWidth, window.innerHeight);
            gl.uniform2f(this.uniforms.groupOffset, groupBounds.left, groupBounds.top);
            gl.uniform2f(this.uniforms.rgbPosition, this.position.x, this.position.y);
            gl.uniform2f(this.uniforms.rgbVelocity, velocityX, velocityY);
            gl.uniform1i(this.uniforms.texture, 0);

            this.sources.forEach(source => {
                if (source.failed) return;

                if (source.dynamic) {
                    if (source.element instanceof HTMLVideoElement && source.element.readyState < 2) {
                        return;
                    }

                    if (!this.upload(source, source.element)) return;
                }

                if (!source.ready) return;

                const bounds = source.element.getBoundingClientRect();
                if (bounds.width === 0 || bounds.height === 0) return;

                const rect = [
                    bounds.left - groupBounds.left,
                    bounds.top - groupBounds.top,
                    bounds.width,
                    bounds.height
                ];
                const factor = this.textureFactor(source, bounds);

                gl.uniform4fv(this.uniforms.rect, rect);
                gl.uniform2f(this.uniforms.rectSize, bounds.width, bounds.height);
                gl.uniform1f(this.uniforms.cornerRadius, source.cornerRadius);
                gl.uniform2fv(this.uniforms.textureFactor, factor);
                gl.activeTexture(gl.TEXTURE0);
                gl.bindTexture(gl.TEXTURE_2D, source.texture);
                gl.drawArrays(gl.TRIANGLES, 0, 6);
            });

            this.previousPosition.x = this.position.x;
            this.previousPosition.y = this.position.y;
            requestAnimationFrame(() => this.render());
        }
    }

    const effects = [
        {
            canvas: document.getElementById('hero-rgb-effect'),
            container: document.querySelector('.hero-section'),
            selectors: ['.hero-bg-video']
        },
        {
            canvas: document.getElementById('frames-rgb-effect'),
            container: document.querySelector('.sticky-canvas-container'),
            selectors: ['#scroll-canvas']
        },
        {
            canvas: document.getElementById('gallery-rgb-effect'),
            container: document.querySelector('.slide-cards-track'),
            selectors: ['.slide-card img']
        }
    ];

    effects.forEach(effect => {
        if (!effect.canvas || !effect.container) return;

        try {
            const renderer = new RgbEffect(effect.canvas, effect.container);
            effect.selectors.forEach(selector => {
                document.querySelectorAll(selector).forEach(element => {
                    renderer.addSource(element, element instanceof HTMLVideoElement ||
                        element instanceof HTMLCanvasElement);
                });
            });
        } catch (error) {
            console.error('No se pudo inicializar la deformación RGB del cursor.', error);
        }
    });
})();
