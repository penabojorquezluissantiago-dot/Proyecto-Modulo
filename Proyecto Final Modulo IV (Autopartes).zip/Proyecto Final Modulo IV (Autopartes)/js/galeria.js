import { Showcase } from "../Sitio con estructura de galeria deseada/Anemolo-StickyImageEffect-2a8d66a/js/Showcase.js";
import { Slides } from "../Sitio con estructura de galeria deseada/Anemolo-StickyImageEffect-2a8d66a/js/Slides.js";

const app = document.getElementById("app");
const introPanel = document.getElementById("gallery-intro");
const galleryCurtain = document.getElementById("gallery-curtain");
const galleryLoading = document.getElementById("gallery-loading");
const galleryHint = document.getElementById("gallery-hint");

if (!app || !introPanel || !galleryCurtain || !galleryLoading || !galleryHint) {
    throw new Error("Faltan elementos necesarios para inicializar la galería.");
}

const slidesData = [
    {
        image: "resources/frames/blueprint-frame-120.jpg",
        title: "Introducción",
        meta: "MotorCrew · Página de introducción",
        description: "Conoce MotorCrew y descubre todo lo que puedes hacer por tu vehículo.",
        action: "Ir a la introducción"
    },
    {
        image: "https://www.hdcarwallpapers.com/download/rimac_nevera_2022_4k_2-3840x2160.jpg",
        title: "MotorCrew",
        meta: "Autopartes · Ingeniería · Pasión",
        description: "Todo lo que mueve tu proyecto, reunido en un solo lugar.",
        action: "Explorar categorías"
    },
    {
        image: "https://th.bing.com/th/id/R.bea5a52b6d908228428e9f31de405aee?rik=jZnqYYXm3AZmuQ&pid=ImgRaw&r=0",
        title: "Accesorios",
        meta: "01 / Personaliza tu camino",
        description: "Detalles funcionales y de estilo para hacer que cada recorrido se sienta completamente tuyo.",
        action: "Volver a MotorCrew"
    },
    {
        image: "https://images.pexels.com/photos/7238606/pexels-photo-7238606.jpeg?w=1260&h=750&dpr=2",
        title: "Herramientas",
        meta: "02 / Listas para el taller",
        description: "Herramientas confiables para diagnosticar, reparar y cuidar cada pieza con precisión.",
        action: "Volver a MotorCrew"
    },
    {
        image: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&q=85&w=2200",
        title: "Motores",
        meta: "03 / Potencia en movimiento",
        description: "Componentes esenciales para recuperar el rendimiento y mantener tu motor en marcha.",
        action: "Volver a MotorCrew"
    },
    {
        image: "https://images.coches.com/_news_/2014/12/suspension-coche-6.jpeg",
        title: "Suspensión",
        meta: "04 / Control en cada curva",
        description: "Amortiguadores, resortes y componentes para una conducción más estable y cómoda.",
        action: "Volver a MotorCrew"
    },
    {
        image: "https://images.unsplash.com/photo-1555626906-fcf10d6851b4?auto=format&fit=crop&q=85&w=2200",
        title: "Frenos",
        meta: "05 / Confianza para detenerte",
        description: "Pastillas, discos y piezas de frenado que ayudan a mantener el control cuando más importa.",
        action: "Volver a MotorCrew"
    },
    {
        image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=85&w=2200",
        title: "Escape",
        meta: "06 / El carácter del motor",
        description: "Sistemas y componentes de escape para cuidar el flujo, el sonido y el desempeño de tu vehículo.",
        action: "Volver a MotorCrew"
    }
];

const initialIndex = 1;
const slides = new Slides(slidesData);
slides.mount(document.body);

slides.slides.forEach((slide, index) => {
    slide.classList.add(index === 0 ? "gallery-introduction-slide" : "gallery-category-slide");
    slide.dataset.index = String(index);

    const description = document.createElement("p");
    description.className = "slide-description";
    description.textContent = slidesData[index].description;
    slide.insertBefore(description, slide.querySelector(".slide-more"));

    const action = slide.querySelector(".slide-more");
    if (!action) {
        throw new Error(`Falta el enlace de acción de la sección ${index}.`);
    }
    action.href = index === 0 ? "intro.html" : "#gallery-intro";
    action.textContent = slidesData[index].action;
    action.dataset.slideTarget = String(index === 1 ? 2 : 1);
    action.setAttribute("aria-label", `${slidesData[index].action}: ${slidesData[index].title}`);
});

slides.onActiveIndexChange(initialIndex);
slides.disperse(initialIndex);
slides.onMove(-initialIndex);

let activeIndex = initialIndex;
let showcase = null;
let fallbackImage = null;
let fallbackTitle = null;
let introNavigationStarted = false;
let sectionSelectionActive = false;

function updateActiveSection(index) {
    activeIndex = Math.max(0, Math.min(index, slidesData.length - 1));
    const isMotorCrewView = activeIndex === 1;

    document.body.classList.toggle("is-intro-view", isMotorCrewView);
    document.body.classList.toggle("is-category-view", !isMotorCrewView);
    document.body.classList.toggle("is-introduction-selection", activeIndex === 0);
    const showIntroPanel = isMotorCrewView && !sectionSelectionActive;
    introPanel.classList.toggle("is-hidden", !showIntroPanel);
    introPanel.setAttribute("aria-hidden", String(!showIntroPanel));

    const hintCopy = galleryHint.querySelector(".gallery-hint-copy");
    if (hintCopy) {
        hintCopy.textContent = isMotorCrewView
            ? "Arrastra para descubrir las secciones"
            : "Mantén y arrastra para explorar";
    }

    if (fallbackImage && fallbackTitle) {
        fallbackImage.src = slidesData[activeIndex].image;
        fallbackImage.alt = slidesData[activeIndex].title;
        fallbackTitle.textContent = slidesData[activeIndex].title;
    }
}

function startSectionSelection() {
    sectionSelectionActive = true;
    document.body.classList.add("is-selecting");
    introPanel.classList.add("is-hidden");
    introPanel.setAttribute("aria-hidden", "true");
    slides.appear();
}

function finishSectionSelection(index) {
    sectionSelectionActive = false;
    document.body.classList.remove("is-selecting");
    slides.disperse(index);
    updateActiveSection(index);
}

function startIntroNavigation() {
    if (introNavigationStarted) {
        return;
    }

    introNavigationStarted = true;
    galleryLoading.classList.add("is-visible");
    galleryLoading.setAttribute("aria-hidden", "false");

    window.setTimeout(() => {
        galleryLoading.classList.remove("is-visible");
        galleryLoading.setAttribute("aria-hidden", "true");
        galleryCurtain.classList.remove("is-entering");
        galleryCurtain.classList.add("is-leaving");

        const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        window.setTimeout(() => {
            window.location.href = "intro.html";
        }, reducedMotion ? 1 : 1650);
    }, 1000);
}

function updateFallbackSection(index) {
    const targetIndex = Math.max(0, Math.min(index, slidesData.length - 1));
    slides.onActiveIndexChange(targetIndex);
    slides.onMove(-targetIndex);
    finishSectionSelection(targetIndex);

    if (targetIndex === 0) {
        startIntroNavigation();
    }
}

function mountFallback() {
    const fallback = document.createElement("div");
    fallback.className = "webgl-fallback";
    fallback.setAttribute("aria-label", "Galería. Arrastra para cambiar de sección.");

    fallbackImage = document.createElement("img");
    fallbackTitle = document.createElement("h2");
    fallback.append(fallbackImage, fallbackTitle);
    app.append(fallback);

    let dragStart = null;
    fallback.addEventListener("pointerdown", event => {
        if (event.button !== 0) {
            return;
        }
        dragStart = event.clientY;
        startSectionSelection();
        fallback.setPointerCapture(event.pointerId);
    });
    fallback.addEventListener("pointerup", event => {
        if (dragStart === null) {
            return;
        }
        const distance = event.clientY - dragStart;
        if (Math.abs(distance) > 40) {
            updateFallbackSection(activeIndex + (distance < 0 ? 1 : -1));
        } else {
            finishSectionSelection(activeIndex);
        }
        dragStart = null;
    });
    updateActiveSection(activeIndex);
}

function setInitialShowcaseIndex(index) {
    showcase.index.current = -index;
    showcase.index.target = -index;
    showcase.index.initial = -index;
    showcase.index.active = index;

    const gl = showcase.GL;
    gl.currentIndex = index;
    gl.nextIndex = index;
    const uniforms = gl.mesh.material.uniforms;
    uniforms.u_texture.value = gl.textures[index];
    uniforms.u_textureFactor.value = gl.factors[index];
    uniforms.u_texture2.value = gl.textures[index];
    uniforms.u_texture2Factor.value = gl.factors[index];
    uniforms.u_textureProgress.value = 0;
}

try {
    showcase = new Showcase(slidesData, {
        onActiveIndexChange: index => {
            slides.onActiveIndexChange(index);
            updateActiveSection(index);
        },
        onIndexChange: index => slides.onMove(index),
        onZoomOutStart: startSectionSelection,
        onFullscreenStart: ({ activeIndex: index }) => {
            finishSectionSelection(index);
        },
        onFullscreenFinish: ({ activeIndex: index }) => {
            if (index === 0) {
                startIntroNavigation();
            }
        }
    });

    setInitialShowcaseIndex(initialIndex);
    showcase.mount(app);
    showcase.render();
    updateActiveSection(initialIndex);

    window.addEventListener("resize", () => showcase.onResize());
    window.addEventListener("mousemove", event => showcase.onMouseMove(event), { passive: true });
} catch (error) {
    console.error("No se pudo iniciar la galería WebGL; se activará el modo alternativo.", error);
    mountFallback();
}

function goToSection(index) {
    const targetIndex = Math.max(0, Math.min(index, slidesData.length - 1));
    if (!showcase) {
        updateFallbackSection(targetIndex);
        return;
    }

    if (targetIndex === activeIndex) {
        if (targetIndex === 0) {
            startIntroNavigation();
        }
        return;
    }

    showcase.onGrabStart();
    const delta = (-targetIndex - showcase.index.initial) * showcase.index.scrollSize;
    showcase.onGrabMove({ delta });
    showcase.onGrabEnd();
}

document.querySelectorAll(".gallery-intro [data-slide-index], .gallery-store-link, .slide-more")
    .forEach(control => {
        control.addEventListener("pointerdown", event => event.stopPropagation());
    });

document.querySelectorAll(".gallery-intro [data-slide-index]").forEach(button => {
    button.addEventListener("click", () => goToSection(Number(button.dataset.slideIndex)));
});

document.querySelectorAll(".slide-more").forEach(action => {
    action.addEventListener("click", event => {
        event.preventDefault();
        if (Number(action.closest(".slide")?.dataset.index) === 0) {
            startIntroNavigation();
            return;
        }
        goToSection(Number(action.dataset.slideTarget));
    });
});

galleryCurtain.addEventListener("animationend", event => {
    if (event.target === galleryCurtain && galleryCurtain.classList.contains("is-entering")) {
        galleryCurtain.classList.remove("is-entering");
    }
});

updateActiveSection(initialIndex);
