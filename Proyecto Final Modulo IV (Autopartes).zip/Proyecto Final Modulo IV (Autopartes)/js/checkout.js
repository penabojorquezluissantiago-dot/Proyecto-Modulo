document.addEventListener("DOMContentLoaded", async () => {
    const form = document.getElementById("checkout-form");
    const layout = document.getElementById("checkout-layout");
    const summary = document.getElementById("checkout-summary");
    const status = document.getElementById("checkout-status");
    const success = document.getElementById("checkout-success");
    const submit = document.getElementById("place-order");
    const shippingFee = 149;
    const freeShippingThreshold = 1500;
    const taxRate = 0.16;
    let items = [];

    function renderSummary(order) {
        const subtotal = order?.subtotal ?? items.reduce((total, item) => total + item.product.price * item.quantity, 0);
        const tax = order?.tax ?? Math.round(subtotal * taxRate * 100) / 100;
        const shipping = order?.shipping ?? (subtotal >= freeShippingThreshold ? 0 : shippingFee);
        const total = order?.total ?? subtotal + tax + shipping;
        summary.replaceChildren();
        const title = document.createElement("h2");
        title.textContent = order ? "Resumen de compra" : "Resumen del pedido";
        summary.append(title);
        items.forEach(item => {
            const line = document.createElement("p");
            line.className = "summary-line";
            const itemTotal = item.product.price * item.quantity;
            line.innerHTML = `<span>${item.quantity} × ${escapeText(item.product.name)}</span><strong>${MotorCrew.currency.format(itemTotal)}</strong>`;
            summary.append(line);
        });
        [
            ["Subtotal", subtotal],
            ["IVA (16%)", tax],
            ["Envío", shipping]
        ].forEach(([label, amount]) => {
            const line = document.createElement("p");
            line.className = "summary-line";
            const value = label === "Envío" && amount === 0 ? "Gratis" : MotorCrew.currency.format(amount);
            line.innerHTML = `<span>${label}</span><strong>${value}</strong>`;
            summary.append(line);
        });
        const totalLine = document.createElement("p");
        totalLine.className = "summary-line summary-total";
        totalLine.innerHTML = `<span>Total</span><strong>${MotorCrew.currency.format(total)}</strong>`;
        summary.append(totalLine);
        const note = document.createElement("p");
        note.className = "checkout-disclaimer";
        note.textContent = `Envío ${MotorCrew.currency.format(shippingFee)}; gratis desde ${MotorCrew.currency.format(freeShippingThreshold)}. En esta versión el pedido se registra, no se realiza un cargo.`;
        summary.append(note);
    }

    function escapeText(text) {
        const span = document.createElement("span");
        span.textContent = text;
        return span.innerHTML;
    }

    try {
        const [{ user }, cart] = await Promise.all([
            MotorCrew.request("/api/auth/me"),
            MotorCrew.request("/api/cart")
        ]);
        items = cart.items;
        if (!items.length) {
            layout.replaceChildren();
            layout.textContent = "Tu carrito está vacío. ";
            const link = document.createElement("a");
            link.href = "catalogo.html";
            link.textContent = "Explorar el catálogo";
            layout.append(link);
            return;
        }
        form.elements.name.value = user.name;
        form.elements.email.value = user.email;
        renderSummary();
    } catch (error) {
        status.textContent = error.message;
        if (error.status === 401) location.href = `login.html?next=${encodeURIComponent("checkout.html")}`;
        return;
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "Registrando tu pedido...";
        submit.disabled = true;
        try {
            const shippingAddress = Object.fromEntries(new FormData(form));
            const result = await MotorCrew.request("/api/orders", {
                method: "POST",
                body: JSON.stringify({
                    items: items.map(item => ({ productId: item.product.id, quantity: item.quantity })),
                    shippingAddress
                })
            });
            window.dispatchEvent(new Event("motorcrew:cart-updated"));
            const order = result.order;
            layout.hidden = true;
            success.hidden = false;
            success.replaceChildren();
            const heading = document.createElement("h2");
            heading.textContent = "¡Compra realizada exitosamente!";
            const message = document.createElement("p");
            message.textContent = `Tu pedido #${order.id} quedó registrado. Puedes consultar su estado y el resumen desde tu perfil.`;
            const total = document.createElement("p");
            total.className = "success-total";
            total.textContent = `Total del pedido: ${MotorCrew.currency.format(order.total)}`;
            const account = document.createElement("a");
            account.href = "compras.html";
            account.className = "btn btn-primary";
            account.textContent = "Consultar mis compras";
            success.append(heading, message, total, account);
            renderSummary(order);
            status.textContent = "";
        } catch (error) {
            status.textContent = error.message;
            submit.disabled = false;
            if (error.status === 401) location.href = `login.html?next=${encodeURIComponent("checkout.html")}`;
        }
    });
});
