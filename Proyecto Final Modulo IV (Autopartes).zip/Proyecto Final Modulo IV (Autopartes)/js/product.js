document.addEventListener("DOMContentLoaded", async () => {
    const container = document.getElementById("product-detail");
    const reviewList = document.getElementById("review-list");
    const reviewSummary = document.getElementById("review-summary");
    const reviewFormWrap = document.getElementById("review-form-wrap");
    const reviewForm = document.getElementById("review-form");
    const reviewStarPicker = document.getElementById("review-star-picker");
    const reviewRatingDescription = document.getElementById("review-rating-description");
    const removeImagesWrap = document.getElementById("review-remove-images-wrap");
    const cancelEdit = document.getElementById("review-cancel-edit");
    const status = document.getElementById("product-status");
    const id = new URLSearchParams(location.search).get("id");
    const ratingLabels = ["Malo", "Regular", "Bueno", "Muy bueno", "Cumplió con lo esperado"];
    let product;
    let reviews = [];
    let ownReview = null;
    let canReview = false;
    let productRating;

    function renderStars(rating, className = "review-stars") {
        const stars = document.createElement("span");
        stars.className = className;
        stars.setAttribute("aria-label", `${rating} de 5 estrellas`);
        for (let value = 1; value <= 5; value += 1) {
            const star = document.createElement("span");
            star.className = value <= Math.round(rating) ? "is-filled" : "";
            star.textContent = "★";
            stars.append(star);
        }
        return stars;
    }

    function renderSummary() {
        reviewSummary.replaceChildren();
        if (!reviews.length) {
            reviewSummary.textContent = "Aún no hay calificaciones";
            if (productRating) productRating.textContent = "Este producto aún no tiene reseñas.";
            return;
        }
        const average = reviews.reduce((total, review) => total + review.rating, 0) / reviews.length;
        if (productRating) productRating.textContent = `★ ${average.toFixed(1)} de 5 · ${reviews.length} reseña(s)`;
        const score = document.createElement("strong");
        score.className = "review-average";
        score.textContent = average.toFixed(1);
        const stars = renderStars(average, "review-stars review-summary-stars");
        const count = document.createElement("span");
        count.className = "review-count";
        count.textContent = `${reviews.length} ${reviews.length === 1 ? "reseña" : "reseñas"}`;
        reviewSummary.append(score, stars, count);
    }

    function reviewCard(review) {
        const article = document.createElement("article");
        article.className = "review-card";
        const header = document.createElement("div");
        header.className = "review-card-header";
        const author = document.createElement("h3");
        author.textContent = review.buyerName;
        header.append(author, renderStars(review.rating));
        const comment = document.createElement("p");
        comment.className = "review-comment";
        comment.textContent = review.comment;
        article.append(header, comment);

        if (review.images?.length) {
            const gallery = document.createElement("div");
            gallery.className = "review-images";
            review.images.forEach((url, index) => {
                const image = document.createElement("img");
                image.src = url;
                image.alt = `Foto ${index + 1} compartida en la reseña de ${review.buyerName}`;
                image.loading = "lazy";
                gallery.append(image);
            });
            article.append(gallery);
        }

        const footer = document.createElement("div");
        footer.className = "review-card-footer";
        const date = document.createElement("time");
        date.dateTime = review.createdAt;
        date.textContent = new Date(review.createdAt).toLocaleDateString("es-MX");
        footer.append(date);
        if (ownReview?.id === review.id) {
            const actions = document.createElement("div");
            actions.className = "review-actions";
            const edit = document.createElement("button");
            edit.type = "button";
            edit.className = "text-button";
            edit.textContent = "Editar";
            edit.addEventListener("click", () => beginEdit(review));
            const remove = document.createElement("button");
            remove.type = "button";
            remove.className = "text-button";
            remove.textContent = "Eliminar";
            remove.addEventListener("click", () => deleteReview(review));
            actions.append(edit, remove);
            footer.append(actions);
        }
        article.append(footer);
        return article;
    }

    function renderReviews() {
        reviewList.replaceChildren();
        if (reviews.length) {
            reviews.forEach(review => reviewList.append(reviewCard(review)));
        } else {
            const empty = document.createElement("p");
            empty.className = "store-message";
            empty.textContent = "Sé la primera persona en compartir una opinión después de comprar.";
            reviewList.append(empty);
        }
        renderSummary();
    }

    function updateStarPicker(rating) {
        const selected = Math.min(5, Math.max(1, Number(rating) || 1));
        reviewForm.elements.rating.value = String(selected);
        reviewRatingDescription.textContent = ratingLabels[selected - 1];
        [...reviewStarPicker.children].forEach((button, index) => {
            const active = index < selected;
            button.classList.toggle("is-selected", active);
            button.setAttribute("aria-checked", String(index + 1 === selected));
        });
    }

    function buildStarPicker() {
        ratingLabels.forEach((label, index) => {
            const rating = index + 1;
            const button = document.createElement("button");
            button.type = "button";
            button.className = "review-star-choice";
            button.setAttribute("role", "radio");
            button.setAttribute("aria-label", `${rating} ${rating === 1 ? "estrella" : "estrellas"} — ${label}`);
            button.setAttribute("aria-checked", "false");
            button.textContent = "★";
            button.addEventListener("click", () => updateStarPicker(rating));
            reviewStarPicker.append(button);
        });
        updateStarPicker(5);
    }

    function resetReviewForm() {
        reviewForm.reset();
        reviewForm.dataset.reviewId = "";
        reviewFormWrap.querySelector("h3").textContent = "Comparte tu experiencia";
        reviewForm.querySelector('button[type="submit"]').textContent = "Publicar reseña";
        cancelEdit.hidden = true;
        removeImagesWrap.hidden = true;
        reviewForm.elements.removeImages.checked = false;
        updateStarPicker(5);
        reviewFormWrap.hidden = !canReview || Boolean(ownReview);
    }

    function beginEdit(review) {
        ownReview = review;
        reviewForm.dataset.reviewId = String(review.id);
        reviewForm.elements.comment.value = review.comment;
        updateStarPicker(review.rating);
        reviewFormWrap.hidden = false;
        reviewFormWrap.querySelector("h3").textContent = "Edita tu reseña";
        reviewForm.querySelector('button[type="submit"]').textContent = "Guardar cambios";
        cancelEdit.hidden = false;
        removeImagesWrap.hidden = !review.images?.length;
        reviewFormWrap.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    async function deleteReview(review) {
        if (!window.confirm("¿Eliminar tu reseña de este producto? Esta acción no se puede deshacer.")) return;
        status.textContent = "Eliminando tu reseña...";
        try {
            await MotorCrew.request(`/api/products/${encodeURIComponent(id)}/reviews/${encodeURIComponent(review.id)}`, { method: "DELETE" });
            reviews = reviews.filter(item => item.id !== review.id);
            ownReview = null;
            renderReviews();
            resetReviewForm();
            status.textContent = "Tu reseña fue eliminada.";
        } catch (error) {
            status.textContent = error.message;
        }
    }

    try {
        if (!id) throw new Error("No se indicó el producto que quieres consultar.");
        const result = await MotorCrew.request(`/api/products/${encodeURIComponent(id)}`);
        product = result.product;
        reviews = result.reviews;
        document.title = `${product.name} | MotorCrew`;
        container.replaceChildren();
        const gallery = document.createElement("div");
        gallery.className = "product-gallery";
        product.images.forEach(url => {
            const image = document.createElement("img");
            image.src = url;
            image.alt = product.name;
            image.loading = "lazy";
            gallery.append(image);
        });
        const details = document.createElement("div");
        details.className = "product-detail-copy";
        const category = document.createElement("p");
        category.className = "tech-badge cyan";
        category.textContent = product.category;
        const title = document.createElement("h1");
        title.className = "section-title";
        title.textContent = product.name;
        const price = document.createElement("p");
        price.className = "product-price product-detail-price";
        price.textContent = MotorCrew.currency.format(product.price);
        const stock = document.createElement("p");
        stock.className = "product-meta";
        stock.textContent = product.stock > 0 ? `${product.stock} unidad(es) disponibles` : "Agotado";
        const seller = document.createElement("p");
        seller.className = "product-meta";
        seller.textContent = `Publicado por ${product.seller.name}`;
        const description = document.createElement("p");
        description.className = "product-description";
        description.textContent = product.description;
        productRating = document.createElement("p");
        productRating.className = "product-meta";
        productRating.textContent = product.reviewCount ? `★ ${product.averageRating.toFixed(1)} de 5 · ${product.reviewCount} reseña(s)` : "Este producto aún no tiene reseñas.";
        const quantityLabel = document.createElement("label");
        quantityLabel.className = "form-group";
        quantityLabel.textContent = "Cantidad";
        const quantity = document.createElement("input");
        quantity.type = "number";
        quantity.min = "1";
        quantity.max = String(Math.max(1, product.stock));
        quantity.value = "1";
        quantityLabel.append(quantity);
        const actions = document.createElement("div");
        actions.className = "product-actions";
        const addToCart = document.createElement("button");
        addToCart.type = "button";
        addToCart.className = "btn btn-primary";
        addToCart.textContent = product.stock > 0 ? "Agregar al carrito" : "Producto agotado";
        addToCart.disabled = product.stock < 1;
        const buyNow = document.createElement("button");
        buyNow.type = "button";
        buyNow.className = "btn btn-glass";
        buyNow.textContent = "Comprar ahora";
        buyNow.disabled = product.stock < 1;
        const favorite = document.createElement("button");
        favorite.type = "button";
        favorite.className = "btn btn-glass favorite-button";
        favorite.textContent = "♡ Guardar en favoritos";

        async function addProduct(andCheckout) {
            const amount = Number(quantity.value);
            if (!Number.isInteger(amount) || amount < 1 || amount > product.stock) {
                status.textContent = `Selecciona una cantidad entre 1 y ${product.stock}.`;
                return;
            }
            status.textContent = "Agregando al carrito...";
            try {
                await MotorCrew.request("/api/cart", {
                    method: "POST",
                    body: JSON.stringify({ productId: product.id, quantity: amount })
                });
                window.dispatchEvent(new Event("motorcrew:cart-updated"));
                if (andCheckout) location.href = "checkout.html";
                else {
                    status.textContent = "Producto agregado al carrito.";
                    const cartCount = document.querySelector(".cart-count");
                    if (cartCount) {
                        cartCount.textContent = String(Number(cartCount.textContent) + amount);
                        cartCount.hidden = false;
                    }
                }
            } catch (error) {
                status.textContent = error.message;
                if (error.status === 401) location.href = `login.html?next=${encodeURIComponent(location.pathname + location.search)}`;
            }
        }
        addToCart.addEventListener("click", () => addProduct(false));
        buyNow.addEventListener("click", () => addProduct(true));
        favorite.addEventListener("click", async () => {
            try {
                const { favorites } = await MotorCrew.request("/api/favorites");
                const isFavorite = favorites.some(item => item.id === product.id);
                await MotorCrew.request(isFavorite ? `/api/favorites/${encodeURIComponent(product.id)}` : "/api/favorites", {
                    method: isFavorite ? "DELETE" : "POST",
                    ...(isFavorite ? {} : { body: JSON.stringify({ productId: product.id }) })
                });
                favorite.textContent = isFavorite ? "♡ Guardar en favoritos" : "♥ En tus favoritos";
                status.textContent = isFavorite ? "Producto eliminado de tus favoritos." : "Producto guardado en tus favoritos.";
            } catch (error) {
                status.textContent = error.message;
                if (error.status === 401) location.href = `login.html?next=${encodeURIComponent(location.pathname + location.search)}`;
            }
        });
        actions.append(addToCart, buyNow, favorite);
        details.append(category, title, productRating, price, stock, seller, description, quantityLabel, actions);
        container.append(gallery, details);
        renderReviews();
        buildStarPicker();

        const session = await MotorCrew.request("/api/auth/me").catch(error => {
            if (error.status !== 401) console.error(error);
            return null;
        });
        if (session && ["BUYER", "BOTH"].includes(session.user.role)) {
            const ownReviewResult = await MotorCrew.request(`/api/products/${encodeURIComponent(id)}/reviews/mine`);
            ownReview = ownReviewResult.review;
            canReview = ownReviewResult.canReview;
            if (ownReview) {
                reviews = reviews.map(review => review.id === ownReview.id ? ownReview : review);
            }
            renderReviews();
            reviewFormWrap.hidden = !canReview || Boolean(ownReview);
            const { favorites } = await MotorCrew.request("/api/favorites");
            if (favorites.some(item => item.id === product.id)) favorite.textContent = "♥ En tus favoritos";
        } else {
            favorite.hidden = true;
            addToCart.hidden = true;
            buyNow.hidden = true;
        }
    } catch (error) {
        container.textContent = error.message;
    }

    cancelEdit.addEventListener("click", resetReviewForm);
    reviewForm.addEventListener("submit", async event => {
        event.preventDefault();
        const files = [...reviewForm.elements.reviewImages.files];
        if (files.length > 3 || files.some(file => file.size > 5 * 1024 * 1024)) {
            status.textContent = "Adjunta como máximo 3 fotos de 5 MB cada una.";
            return;
        }
        const reviewId = reviewForm.dataset.reviewId;
        const body = new FormData(reviewForm);
        body.set("rating", reviewForm.elements.rating.value);
        status.textContent = reviewId ? "Guardando cambios..." : "Publicando reseña...";
        const submit = reviewForm.querySelector('button[type="submit"]');
        submit.disabled = true;
        try {
            const result = await MotorCrew.request(
                reviewId
                    ? `/api/products/${encodeURIComponent(id)}/reviews/${encodeURIComponent(reviewId)}`
                    : `/api/products/${encodeURIComponent(id)}/reviews`,
                { method: reviewId ? "PUT" : "POST", body }
            );
            ownReview = result.review;
            if (reviewId) {
                reviews = reviews.map(review => review.id === ownReview.id ? ownReview : review);
            } else {
                reviews.unshift(ownReview);
            }
            renderReviews();
            resetReviewForm();
            status.textContent = reviewId ? "Tu reseña fue actualizada." : "Gracias, tu reseña fue publicada.";
        } catch (error) {
            status.textContent = error.message;
            if (error.status === 401) location.href = `login.html?next=${encodeURIComponent(location.pathname + location.search)}`;
        } finally {
            submit.disabled = false;
        }
    });
});
