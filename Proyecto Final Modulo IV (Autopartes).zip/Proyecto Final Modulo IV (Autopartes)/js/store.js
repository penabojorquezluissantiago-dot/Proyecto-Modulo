(() => {
    const currency = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" });
    const activeAccountStorageKey = "motorcrew.activeAccountId";

    async function request(url, options = {}) {
        const headers = new Headers(options.headers || {});
        const activeAccountId = localStorage.getItem(activeAccountStorageKey);
        if (activeAccountId) headers.set("X-MotorCrew-Account", activeAccountId);
        if (options.body && !(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
        const response = await fetch(url, { ...options, headers, credentials: "same-origin" });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
            const error = new Error(data.error || "No se pudo completar la solicitud.");
            error.status = response.status;
            throw error;
        }
        return data;
    }

    function productCard(product) {
        const card = document.createElement("article");
        card.className = "product-card glass-panel";
        const link = document.createElement("a");
        link.className = "product-card-link";
        link.href = `producto.html?id=${encodeURIComponent(product.id)}`;
        link.setAttribute("aria-label", `Ver ${product.name}`);
        if (product.images?.length) {
            const image = document.createElement("img");
            image.className = "product-img";
            image.src = product.images[0];
            image.alt = product.name;
            image.loading = "lazy";
            link.append(image);
        } else {
            const placeholder = document.createElement("div");
            placeholder.className = "product-img product-placeholder";
            placeholder.textContent = "MOTORCREW";
            link.append(placeholder);
        }
        const title = document.createElement("h3");
        title.className = "product-title";
        title.textContent = product.name;
        const category = document.createElement("p");
        category.className = "product-meta product-card-meta";
        category.textContent = product.category;
        const rating = document.createElement("p");
        rating.className = "product-rating-meta";
        if (product.reviewCount) {
            const star = document.createElement("span");
            star.className = "product-rating-star";
            star.setAttribute("aria-hidden", "true");
            star.textContent = "★";
            const score = document.createElement("span");
            score.textContent = Number(product.averageRating).toFixed(1);
            rating.append(star, score);
            rating.setAttribute("aria-label", `Calificación promedio: ${Number(product.averageRating).toFixed(1)} de 5`);
        } else {
            rating.textContent = "Sin reseñas";
        }
        const price = document.createElement("p");
        price.className = "product-price";
        price.textContent = currency.format(product.price);
        const details = document.createElement("span");
        details.className = "btn btn-primary";
        details.textContent = "Ver producto";
        link.append(title, category, rating, price, details);
        card.append(link);
        return card;
    }

    function createAccountControls(user) {
        let header = document.querySelector("header");
        if (!header) {
            header = document.createElement("header");
            document.body.prepend(header);
        }
        header.replaceChildren();
        const logo = document.createElement("a");
        logo.className = "logo";
        logo.href = "index.html";
        const logoMark = document.createElement("span");
        logoMark.textContent = "//";
        logo.append(logoMark, document.createTextNode(" MOTORCREW"));

        const navigation = document.createElement("nav");
        navigation.className = "header-navigation";
        navigation.setAttribute("aria-label", "Navegación principal");
        const navigationList = document.createElement("ul");
        const pages = user?.role === "ADMIN"
            ? [["admin.html", "Administración"]]
            : [["index.html", "Inicio"], ["catalogo.html", "Catálogo"]];
        if (user?.role !== "ADMIN" && (!user || ["SELLER", "BOTH"].includes(user.role))) {
            pages.push(["publicar.html", user ? "Mis publicaciones" : "Vender"]);
        }
        if (user?.role !== "ADMIN") pages.push(["galeria.html", "Galería"], ["historia.html", "Historia"], ["contacto.html", "Contacto"]);
        pages.forEach(([href, label]) => {
            const item = document.createElement("li");
            const link = document.createElement("a");
            link.href = href;
            link.textContent = label;
            if (location.pathname.toLowerCase().endsWith(href)) link.setAttribute("aria-current", "page");
            item.append(link);
            navigationList.append(item);
        });
        navigation.append(navigationList);
        const navToggle = document.createElement("button");
        navToggle.type = "button";
        navToggle.className = "header-nav-toggle";
        navToggle.setAttribute("aria-label", "Abrir navegación");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.textContent = "☰";
        navToggle.addEventListener("click", () => {
            const isOpen = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isOpen));
            navToggle.setAttribute("aria-label", isOpen ? "Abrir navegación" : "Cerrar navegación");
            navigation.classList.toggle("is-open", !isOpen);
        });
        const controls = document.createElement("div");
        controls.className = "account-controls";
        if (!user) {
            const loginLink = document.createElement("a");
            loginLink.href = "login.html";
            loginLink.className = "btn btn-glass";
            loginLink.textContent = "Iniciar sesión";
            controls.append(loginLink);
        } else {
            localStorage.setItem(activeAccountStorageKey, String(user.id));
            if (["BUYER", "BOTH"].includes(user.role)) {
                const cartLink = document.createElement("a");
                cartLink.className = "btn btn-glass cart-header-link";
                cartLink.href = "carrito.html";
                cartLink.setAttribute("aria-label", "Mi carrito");
                cartLink.title = "Mi carrito";
                const cartIcon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                cartIcon.setAttribute("class", "cart-icon");
                cartIcon.setAttribute("viewBox", "0 0 24 24");
                cartIcon.setAttribute("aria-hidden", "true");
                const cartShape = document.createElementNS("http://www.w3.org/2000/svg", "path");
                cartShape.setAttribute("d", "M3 4h2l2.4 11h10.8l2-8H6M9 19a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm8 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z");
                cartIcon.append(cartShape);
                const badge = document.createElement("span");
                badge.className = "cart-count";
                badge.setAttribute("aria-label", "Artículos en el carrito");
                badge.textContent = "0";
                badge.hidden = true;
                cartLink.append(cartIcon, badge);
                controls.append(cartLink);
            }

            const profile = document.createElement("div");
            profile.className = "profile-menu";
            const toggle = document.createElement("button");
            toggle.className = "profile-toggle";
            toggle.type = "button";
            toggle.setAttribute("aria-expanded", "false");
            toggle.setAttribute("aria-label", `Abrir menú de ${user.name}`);
            const avatar = document.createElementNS("http://www.w3.org/2000/svg", "svg");
            avatar.setAttribute("class", "profile-avatar");
            avatar.setAttribute("viewBox", "0 0 24 24");
            avatar.setAttribute("aria-hidden", "true");
            const avatarShape = document.createElementNS("http://www.w3.org/2000/svg", "path");
            avatarShape.setAttribute("d", "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z");
            avatar.append(avatarShape);
            const name = document.createElement("span");
            name.className = "profile-name";
            name.textContent = user.name;
            toggle.append(avatar, name);

            const menu = document.createElement("div");
            menu.className = "profile-dropdown";
            menu.hidden = true;
            const links = user.role === "ADMIN"
                ? [["admin.html", "Panel de administración"], ["configuracion.html", "Seguridad de la cuenta"]]
                : [["cuenta.html", "Mi perfil"]];
            if (["BUYER", "BOTH"].includes(user.role)) {
                links.push(["compras.html", "Mis compras"], ["favoritos.html", "Mis favoritos"]);
            }
            if (user.role !== "ADMIN") links.push(["configuracion.html", "Configuración"]);
            if (["SELLER", "BOTH"].includes(user.role)) links.push(["publicar.html", "Mis publicaciones"]);
            links.forEach(([href, label]) => {
                const link = document.createElement("a");
                link.href = href;
                link.textContent = label;
                menu.append(link);
            });
            const switchUser = document.createElement("button");
            switchUser.type = "button";
            switchUser.className = "profile-menu-action";
            switchUser.textContent = "Cambiar de usuario";
            switchUser.setAttribute("aria-expanded", "false");
            const sessionsMenu = document.createElement("div");
            sessionsMenu.className = "profile-sessions";
            sessionsMenu.hidden = true;
            sessionsMenu.setAttribute("aria-label", "Sesiones guardadas en este navegador");
            const logout = document.createElement("button");
            logout.type = "button";
            logout.className = "profile-menu-action is-danger";
            logout.textContent = "Cerrar sesión";
            menu.append(switchUser, sessionsMenu, logout);
            toggle.addEventListener("click", () => {
                const isOpen = toggle.getAttribute("aria-expanded") === "true";
                toggle.setAttribute("aria-expanded", String(!isOpen));
                menu.hidden = isOpen;
            });
            document.addEventListener("click", event => {
                if (!profile.contains(event.target)) {
                    toggle.setAttribute("aria-expanded", "false");
                    menu.hidden = true;
                }
            });
            document.addEventListener("keydown", event => {
                if (event.key === "Escape") {
                    toggle.setAttribute("aria-expanded", "false");
                    menu.hidden = true;
                    navigation.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
            switchUser.addEventListener("click", async () => {
                const isOpen = switchUser.getAttribute("aria-expanded") === "true";
                if (isOpen) {
                    switchUser.setAttribute("aria-expanded", "false");
                    sessionsMenu.hidden = true;
                    return;
                }
                switchUser.disabled = true;
                switchUser.setAttribute("aria-expanded", "true");
                sessionsMenu.hidden = false;
                sessionsMenu.replaceChildren();
                const loading = document.createElement("p");
                loading.className = "profile-sessions-message";
                loading.textContent = "Buscando sesiones guardadas...";
                sessionsMenu.append(loading);
                try {
                    const { sessions } = await request("/api/auth/sessions");
                    sessionsMenu.replaceChildren();
                    if (sessions.length > 1) {
                        sessions.forEach(session => {
                            const select = document.createElement("button");
                            select.type = "button";
                            select.className = "profile-session-option";
                            select.textContent = `${session.name} · ${session.email}${session.isCurrent ? " · Sesión actual" : ""}`;
                            select.disabled = session.isCurrent;
                            select.addEventListener("click", () => {
                                localStorage.setItem(activeAccountStorageKey, String(session.id));
                                location.reload();
                            });
                            sessionsMenu.append(select);
                        });
                    } else {
                        const empty = document.createElement("p");
                        empty.className = "profile-sessions-message";
                        empty.textContent = "No hay otras sesiones guardadas en este navegador.";
                        sessionsMenu.append(empty);
                    }
                    const addAccount = document.createElement("a");
                    addAccount.className = "profile-session-add";
                    addAccount.href = `login.html?next=${encodeURIComponent(location.pathname + location.search + location.hash)}`;
                    addAccount.textContent = "Iniciar sesión con otra cuenta";
                    sessionsMenu.append(addAccount);
                } catch (error) {
                    sessionsMenu.replaceChildren();
                    const message = document.createElement("p");
                    message.className = "profile-sessions-message is-error";
                    message.textContent = error.message;
                    sessionsMenu.append(message);
                } finally {
                    switchUser.disabled = false;
                }
            });

            async function signOut() {
                try {
                    await request("/api/auth/logout", { method: "POST" });
                    localStorage.removeItem(activeAccountStorageKey);
                    location.href = "index.html";
                } catch (error) {
                    menu.dataset.error = error.message;
                    menu.setAttribute("aria-label", error.message);
                }
            }
            logout.addEventListener("click", signOut);
            profile.append(toggle, menu);
            controls.append(profile);
        }
        header.append(logo, navToggle, navigation, controls);

        if (user && ["BUYER", "BOTH"].includes(user.role)) refreshCartCount();
    }

    async function refreshCartCount() {
        const badge = document.querySelector(".cart-count");
        if (!badge) return;
        try {
            const { items } = await request("/api/cart");
            const count = items.reduce((total, item) => total + item.quantity, 0);
            badge.textContent = String(count);
            badge.hidden = count === 0;
        } catch (error) {
            if (error.status !== 401) console.error(error);
        }
    }

    function setActiveAccount(user) {
        localStorage.setItem(activeAccountStorageKey, String(user.id));
    }

    window.MotorCrew = { request, productCard, currency, refreshCartCount, setActiveAccount };

    document.addEventListener("DOMContentLoaded", () => {
        window.addEventListener("motorcrew:cart-updated", refreshCartCount);
        request("/api/auth/me").then(({ user }) => createAccountControls(user)).catch(error => {
            if (error.status !== 401) console.error(error);
            createAccountControls(null);
        });
    });
})();
