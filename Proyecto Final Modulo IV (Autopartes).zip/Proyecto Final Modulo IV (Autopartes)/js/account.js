document.addEventListener("DOMContentLoaded", async () => {
    const greeting = document.getElementById("account-greeting");
    const favoritesList = document.getElementById("favorite-products");
    const ordersList = document.getElementById("purchase-list");
    const status = document.getElementById("account-status");
    const deleteForm = document.getElementById("delete-account-form");
    const profileForm = document.getElementById("account-profile-form");
    const passwordForm = document.getElementById("account-password-form");
    const activeAccountStorageKey = "motorcrew.activeAccountId";
    let accountUserId;

    profileForm?.addEventListener("submit", async event => {
        event.preventDefault();
        const submit = profileForm.querySelector('button[type="submit"]');
        submit.disabled = true;
        try {
            const { user, message } = await MotorCrew.request("/api/auth/me", {
                method: "PUT",
                body: JSON.stringify({ name: profileForm.elements.name.value })
            });
            profileForm.elements.name.value = user.name;
            if (greeting) greeting.textContent = `${user.name} · ${user.email}`;
            const profileName = document.querySelector(".profile-name");
            if (profileName) profileName.textContent = user.name;
            const profileToggle = document.querySelector(".profile-toggle");
            if (profileToggle) profileToggle.setAttribute("aria-label", `Abrir menú de ${user.name}`);
            status.textContent = message;
        } catch (error) {
            status.textContent = error.message;
        } finally {
            submit.disabled = false;
        }
    });

    passwordForm?.addEventListener("submit", async event => {
        event.preventDefault();
        const submit = passwordForm.querySelector('button[type="submit"]');
        const newPassword = passwordForm.elements.newPassword.value;
        if (newPassword !== passwordForm.elements.confirmPassword.value) {
            status.textContent = "La nueva contraseña y su confirmación no coinciden.";
            return;
        }
        submit.disabled = true;
        try {
            const { user, message } = await MotorCrew.request("/api/auth/me", {
                method: "PUT",
                body: JSON.stringify({
                    currentPassword: passwordForm.elements.currentPassword.value,
                    newPassword
                })
            });
            MotorCrew.setActiveAccount(user);
            passwordForm.reset();
            status.textContent = message;
        } catch (error) {
            status.textContent = error.message;
        } finally {
            submit.disabled = false;
        }
    });

    if (deleteForm) {
        deleteForm.addEventListener("submit", async event => {
            event.preventDefault();
            if (!window.confirm("¿Eliminar permanentemente tu cuenta y tus datos personales? Esta acción no se puede deshacer.")) return;
            const submit = deleteForm.querySelector('button[type="submit"]');
            submit.disabled = true;
            status.textContent = "Eliminando tu cuenta...";
            try {
                const { message } = await MotorCrew.request("/api/auth/me", {
                    method: "DELETE",
                    body: JSON.stringify({ password: deleteForm.elements.password.value })
                });
                localStorage.removeItem(activeAccountStorageKey);
                status.textContent = message;
                window.setTimeout(() => { location.href = "index.html"; }, 1800);
            } catch (error) {
                status.textContent = error.message;
                submit.disabled = false;
            }
        });
    }

    function renderOrder(order) {
        const article = document.createElement("article");
        article.className = "purchase-card glass-panel";
        const heading = document.createElement("h3");
        heading.textContent = `Pedido #${order.buyer?.id ?? accountUserId}-${order.orderNumber}`;
        const date = document.createElement("p");
        date.className = "product-meta";
        date.textContent = new Date(order.createdAt).toLocaleString("es-MX");
        const state = document.createElement("span");
        state.className = "order-status";
        state.textContent = order.status === "PENDING" ? "Pedido registrado" : order.status;
        const items = document.createElement("ul");
        order.items.forEach(item => {
            const line = document.createElement("li");
            line.textContent = `${item.quantity} × ${item.name} — ${MotorCrew.currency.format(item.price * item.quantity)}`;
            items.append(line);
        });
        const totals = document.createElement("div");
        totals.className = "purchase-totals";
        [
            ["Productos", order.subtotal],
            ["IVA", order.tax],
            ["Envío", order.shipping],
            ["Total", order.total]
        ].forEach(([label, value]) => {
            const line = document.createElement("p");
            line.className = label === "Total" ? "summary-line summary-total" : "summary-line";
            const amount = label === "Envío" && value === 0 ? "Gratis" : MotorCrew.currency.format(value);
            line.innerHTML = `<span>${label}</span><strong>${amount}</strong>`;
            totals.append(line);
        });
        article.append(heading, date, state, items, totals);
        if (order.shippingAddress) {
            const address = document.createElement("p");
            address.className = "product-meta";
            const { street, neighborhood, postalCode, city, state: region } = order.shippingAddress;
            address.textContent = `Entrega: ${street}, ${neighborhood}, C.P. ${postalCode}, ${city}, ${region}`;
            article.append(address);
        }
        return article;
    }

    try {
        const { user } = await MotorCrew.request("/api/auth/me");
        accountUserId = user.id;
        if (greeting) greeting.textContent = `${user.name} · ${user.email}`;
        if (profileForm) profileForm.elements.name.value = user.name;
        if (user.role === "ADMIN") document.querySelectorAll("[data-non-admin]").forEach(section => { section.hidden = true; });
        if (!["BUYER", "BOTH"].includes(user.role)) {
            document.querySelectorAll("[data-buyer-only]").forEach(section => { section.hidden = true; });
            return;
        }
        if (favoritesList) {
            const { favorites } = await MotorCrew.request("/api/favorites");
            if (favorites.length) {
                favorites.forEach(product => {
                    const card = MotorCrew.productCard(product);
                    const remove = document.createElement("button");
                    remove.type = "button";
                    remove.className = "text-button";
                    remove.textContent = "Quitar de favoritos";
                    remove.addEventListener("click", async () => {
                        try {
                            await MotorCrew.request(`/api/favorites/${encodeURIComponent(product.id)}`, { method: "DELETE" });
                            card.remove();
                            if (!favoritesList.children.length) favoritesList.textContent = "Aún no tienes productos favoritos.";
                        } catch (error) {
                            status.textContent = error.message;
                        }
                    });
                    card.append(remove);
                    favoritesList.append(card);
                });
            } else {
                favoritesList.textContent = "Aún no tienes productos favoritos. Guarda piezas desde su página para encontrarlas aquí.";
            }
        }
        if (ordersList) {
            const { orders } = await MotorCrew.request("/api/orders/mine");
            if (orders.length) orders.forEach(order => ordersList.append(renderOrder(order)));
            else ordersList.textContent = "Todavía no tienes compras. Tus pedidos aparecerán aquí cuando confirmes uno.";
        }
    } catch (error) {
        if (status) status.textContent = error.message;
        if (error.status === 401) location.href = `login.html?next=${encodeURIComponent(location.pathname + location.search + location.hash)}`;
    }
});
