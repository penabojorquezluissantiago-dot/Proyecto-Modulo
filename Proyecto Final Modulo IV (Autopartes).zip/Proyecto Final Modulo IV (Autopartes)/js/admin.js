document.addEventListener("DOMContentLoaded", async () => {
    const status = document.getElementById("admin-status");
    const greeting = document.getElementById("admin-greeting");
    const content = document.getElementById("admin-content");
    const metrics = document.getElementById("admin-metrics");
    const usersList = document.getElementById("admin-users");
    const productsList = document.getElementById("admin-products");
    const ordersList = document.getElementById("admin-orders");
    const schemaList = document.getElementById("admin-schema");

    function showError(error) {
        status.textContent = error.message;
    }

    function metric(label, value) {
        const card = document.createElement("article");
        card.className = "glass-panel admin-metric";
        const heading = document.createElement("span");
        heading.textContent = label;
        const amount = document.createElement("strong");
        amount.textContent = value;
        card.append(heading, amount);
        return card;
    }

    function renderBars(container, rows, { label, formatter = String, emptyText }) {
        container.replaceChildren();
        container.setAttribute("aria-label", label);
        if (!rows.length) {
            const empty = document.createElement("p");
            empty.className = "admin-empty";
            empty.textContent = emptyText;
            container.append(empty);
            return;
        }
        const max = Math.max(1, ...rows.map(row => Number(row.value)));
        rows.forEach(row => {
            const item = document.createElement("div");
            item.className = "admin-bar-row";
            const caption = document.createElement("div");
            caption.className = "admin-bar-caption";
            const name = document.createElement("span");
            name.textContent = row.name;
            const amount = document.createElement("strong");
            amount.textContent = formatter(row.value);
            caption.append(name, amount);
            const track = document.createElement("div");
            track.className = "admin-bar-track";
            const bar = document.createElement("span");
            bar.style.width = `${Math.max(3, (Number(row.value) / max) * 100)}%`;
            bar.setAttribute("aria-hidden", "true");
            track.append(bar);
            item.append(caption, track);
            container.append(item);
        });
    }

    function renderUser(user) {
        const article = document.createElement("article");
        article.className = "glass-panel admin-record";
        const heading = document.createElement("div");
        heading.className = "admin-record-heading";
        const identity = document.createElement("div");
        const name = document.createElement("h3");
        name.textContent = `${user.name} · #${user.id}`;
        const email = document.createElement("p");
        email.className = "product-meta";
        email.textContent = user.email;
        identity.append(name, email);
        const summary = document.createElement("span");
        summary.className = "admin-record-meta";
        summary.textContent = `${user.orderCount} pedidos · ${user.productCount} productos · ${new Date(user.createdAt).toLocaleDateString("es-MX")}`;
        heading.append(identity, summary);
        article.append(heading);
        if (user.role === "ADMIN") {
            const badge = document.createElement("p");
            badge.className = "order-status";
            badge.textContent = "Cuenta de administración protegida";
            article.append(badge);
            return article;
        }

        const editForm = document.createElement("form");
        editForm.className = "admin-inline-form";
        const nameInput = document.createElement("input");
        nameInput.name = "name";
        nameInput.setAttribute("aria-label", `Nombre de ${user.email}`);
        nameInput.value = user.name;
        nameInput.required = true;
        nameInput.minLength = 2;
        nameInput.maxLength = 80;
        const roleSelect = document.createElement("select");
        roleSelect.name = "role";
        roleSelect.setAttribute("aria-label", `Tipo de cuenta de ${user.email}`);
        [["BUYER", "Comprador"], ["SELLER", "Vendedor"], ["BOTH", "Comprador y vendedor"]].forEach(([value, label]) => {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = label;
            option.selected = user.role === value;
            roleSelect.append(option);
        });
        const save = document.createElement("button");
        save.className = "btn btn-primary";
        save.type = "submit";
        save.textContent = "Guardar cambios";
        editForm.append(nameInput, roleSelect, save);
        editForm.addEventListener("submit", async event => {
            event.preventDefault();
            save.disabled = true;
            try {
                const result = await MotorCrew.request(`/api/admin/users/${encodeURIComponent(user.id)}`, {
                    method: "PUT",
                    body: JSON.stringify({ name: nameInput.value, role: roleSelect.value })
                });
                status.textContent = result.message;
                await loadUsers();
            } catch (error) {
                showError(error);
                save.disabled = false;
            }
        });

        const passwordForm = document.createElement("form");
        passwordForm.className = "admin-inline-form admin-password-form";
        const passwordInput = document.createElement("input");
        passwordInput.name = "password";
        passwordInput.type = "password";
        passwordInput.autocomplete = "new-password";
        passwordInput.placeholder = "Nueva contraseña (mín. 8)";
        passwordInput.setAttribute("aria-label", `Nueva contraseña de ${user.email}`);
        passwordInput.required = true;
        passwordInput.minLength = 8;
        passwordInput.maxLength = 72;
        const changePassword = document.createElement("button");
        changePassword.className = "btn btn-glass";
        changePassword.type = "submit";
        changePassword.textContent = "Cambiar contraseña";
        passwordForm.append(passwordInput, changePassword);
        passwordForm.addEventListener("submit", async event => {
            event.preventDefault();
            changePassword.disabled = true;
            try {
                const result = await MotorCrew.request(`/api/admin/users/${encodeURIComponent(user.id)}/password`, {
                    method: "PUT",
                    body: JSON.stringify({ password: passwordInput.value })
                });
                passwordForm.reset();
                status.textContent = result.message;
            } catch (error) {
                showError(error);
            } finally {
                changePassword.disabled = false;
            }
        });

        const remove = document.createElement("button");
        remove.className = "btn btn-danger";
        remove.type = "button";
        remove.textContent = "Eliminar usuario";
        remove.addEventListener("click", async () => {
            if (!window.confirm(`¿Eliminar permanentemente la cuenta de ${user.name}? Los pedidos anteriores quedarán anonimizados.`)) return;
            remove.disabled = true;
            try {
                const result = await MotorCrew.request(`/api/admin/users/${encodeURIComponent(user.id)}`, { method: "DELETE" });
                status.textContent = result.message;
                await loadUsers();
            } catch (error) {
                showError(error);
                remove.disabled = false;
            }
        });
        article.append(editForm, passwordForm, remove);
        return article;
    }

    async function loadUsers() {
        const { users } = await MotorCrew.request("/api/admin/users");
        usersList.replaceChildren(...users.map(renderUser));
        if (!users.length) usersList.textContent = "No hay usuarios registrados.";
    }

    function renderProduct(product) {
        const card = MotorCrew.productCard(product);
        const details = document.createElement("p");
        details.className = "product-meta";
        details.textContent = `Vendedor: ${product.sellerName} (#${product.sellerId}) · Stock: ${product.stock} · ${product.isActive ? "Activo" : "Inactivo"}`;
        const remove = document.createElement("button");
        remove.className = "btn btn-danger";
        remove.type = "button";
        remove.textContent = "Eliminar del catálogo";
        remove.addEventListener("click", async () => {
            if (!window.confirm(`¿Eliminar "${product.name}" del catálogo? Los pedidos anteriores conservarán el nombre y el precio.`)) return;
            remove.disabled = true;
            try {
                const result = await MotorCrew.request(`/api/admin/products/${encodeURIComponent(product.id)}`, { method: "DELETE" });
                status.textContent = result.message;
                card.remove();
                if (!productsList.children.length) productsList.textContent = "No hay productos registrados.";
            } catch (error) {
                showError(error);
                remove.disabled = false;
            }
        });
        card.append(details, remove);
        return card;
    }

    function renderOrder(order) {
        const article = document.createElement("article");
        article.className = "glass-panel admin-record";
        const title = document.createElement("h3");
        title.textContent = `Pedido #${order.buyer?.id ?? "anónimo"}-${order.orderNumber ?? order.id}`;
        const buyer = document.createElement("p");
        buyer.className = "product-meta";
        buyer.textContent = order.buyer
            ? `Comprador: ${order.buyer.name} (${order.buyer.email}) · Usuario #${order.buyer.id}`
            : "Comprador eliminado/anónimo";
        const created = document.createElement("p");
        created.className = "product-meta";
        created.textContent = new Date(order.createdAt).toLocaleString("es-MX");
        const items = document.createElement("ul");
        items.className = "admin-order-items";
        order.items.forEach(item => {
            const line = document.createElement("li");
            line.textContent = `${item.quantity} × ${item.name} — ${MotorCrew.currency.format(item.price * item.quantity)}`;
            items.append(line);
        });
        const total = document.createElement("p");
        total.className = "summary-line summary-total";
        total.textContent = `Total: ${MotorCrew.currency.format(order.total)}`;
        const statusForm = document.createElement("form");
        statusForm.className = "admin-inline-form";
        const statusSelect = document.createElement("select");
        statusSelect.setAttribute("aria-label", `Estado del pedido ${order.id}`);
        [["PENDING", "Pendiente"], ["CONFIRMED", "Confirmado"], ["SHIPPED", "Enviado"], ["DELIVERED", "Entregado"], ["CANCELLED", "Cancelado"]].forEach(([value, label]) => {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = label;
            option.selected = order.status === value;
            statusSelect.append(option);
        });
        const saveStatus = document.createElement("button");
        saveStatus.className = "btn btn-glass";
        saveStatus.type = "submit";
        saveStatus.textContent = "Actualizar estado";
        statusForm.append(statusSelect, saveStatus);
        statusForm.addEventListener("submit", async event => {
            event.preventDefault();
            saveStatus.disabled = true;
            try {
                const result = await MotorCrew.request(`/api/admin/orders/${encodeURIComponent(order.id)}`, {
                    method: "PUT",
                    body: JSON.stringify({ status: statusSelect.value })
                });
                status.textContent = result.message;
            } catch (error) {
                showError(error);
            } finally {
                saveStatus.disabled = false;
            }
        });
        article.append(title, buyer, created, items, total);
        if (order.shippingAddress) {
            const address = document.createElement("p");
            address.className = "admin-order-address";
            const { name, phone, street, neighborhood, postalCode, city, state } = order.shippingAddress;
            address.textContent = `Entrega: ${name}, ${phone}, ${street}, ${neighborhood}, C.P. ${postalCode}, ${city}, ${state}`;
            article.append(address);
        }
        article.append(statusForm);
        return article;
    }

    try {
        const { user } = await MotorCrew.request("/api/auth/me");
        if (user.role !== "ADMIN") {
            status.textContent = "Esta página está reservada para la cuenta administradora.";
            return;
        }
        greeting.textContent = `${user.name} · ${user.email}`;
        content.hidden = false;

        const [overview, usersResult, productsResult, ordersResult, schemaResult] = await Promise.all([
            MotorCrew.request("/api/admin/overview"),
            MotorCrew.request("/api/admin/users"),
            MotorCrew.request("/api/admin/products"),
            MotorCrew.request("/api/admin/orders"),
            MotorCrew.request("/api/admin/schema")
        ]);
        const { totals, topProducts, topBuyers, dailySignIns } = overview;
        [
            ["Usuarios", totals.users.toLocaleString("es-MX")],
            ["Productos activos", totals.activeProducts.toLocaleString("es-MX")],
            ["Pedidos", totals.orders.toLocaleString("es-MX")],
            ["Importe de pedidos no cancelados", MotorCrew.currency.format(totals.revenue)],
            ["Usuarios activos · 24 h", totals.activeUsers24h.toLocaleString("es-MX")]
        ].forEach(([label, value]) => metrics.append(metric(label, value)));
        const lastSevenDays = Array.from({ length: 7 }, (_value, index) => {
            const today = new Date();
            const date = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - (6 - index)));
            const key = date.toISOString().slice(0, 10);
            const day = dailySignIns.find(row => row.date === key);
            return { name: date.toLocaleDateString("es-MX", { weekday: "short", day: "numeric", timeZone: "UTC" }), value: day?.users || 0 };
        });
        renderBars(document.getElementById("admin-activity-chart"), lastSevenDays, {
            label: "Usuarios únicos que iniciaron sesión o se registraron durante los últimos siete días",
            formatter: value => `${value} usuarios`,
            emptyText: "No hay actividad registrada."
        });
        renderBars(document.getElementById("admin-products-chart"), topProducts.map(row => ({ name: row.name, value: row.unitsSold })), {
            label: "Productos con más unidades solicitadas en pedidos vigentes",
            formatter: value => `${value} unidades`,
            emptyText: "Aún no hay ventas."
        });
        renderBars(document.getElementById("admin-buyers-chart"), topBuyers.map(row => ({ name: `${row.name} (#${row.id})`, value: row.spent })), {
            label: "Usuarios con mayor importe de pedidos vigentes",
            formatter: value => MotorCrew.currency.format(value),
            emptyText: "Aún no hay compras."
        });
        usersList.replaceChildren(...usersResult.users.map(renderUser));
        if (!usersResult.users.length) usersList.textContent = "No hay usuarios registrados.";
        productsList.replaceChildren(...productsResult.products.map(renderProduct));
        if (!productsResult.products.length) productsList.textContent = "No hay productos registrados.";
        ordersList.replaceChildren(...ordersResult.orders.map(renderOrder));
        if (!ordersResult.orders.length) ordersList.textContent = "Aún no hay pedidos registrados.";
        schemaList.replaceChildren(...schemaResult.tables.map(table => {
            const details = document.createElement("details");
            details.className = "glass-panel admin-schema-table";
            const summary = document.createElement("summary");
            summary.textContent = `${table.name} · ${table.columns.length} columnas`;
            details.append(summary);
            const columns = document.createElement("div");
            columns.className = "admin-schema-columns";
            table.columns.forEach(column => {
                const row = document.createElement("p");
                row.textContent = `${column.name} — ${column.type || "sin tipo"}${column.pk ? " · clave primaria" : ""}${column.notnull ? " · requerido" : ""}`;
                columns.append(row);
            });
            const metadata = document.createElement("p");
            metadata.className = "admin-schema-metadata";
            const foreignKeys = table.foreignKeys.map(key => `${key.from} → ${key.table}.${key.to}`);
            const indexes = table.indexes.map(index => index.name);
            metadata.textContent = `Relaciones: ${foreignKeys.length ? foreignKeys.join(", ") : "ninguna"} · Índices: ${indexes.length ? indexes.join(", ") : "ninguno"}`;
            const definition = document.createElement("pre");
            definition.textContent = table.definition || "";
            details.append(columns, metadata, definition);
            return details;
        }));
    } catch (error) {
        showError(error);
        if (error.status === 401) location.href = `login.html?next=${encodeURIComponent("admin.html")}`;
    }
});
