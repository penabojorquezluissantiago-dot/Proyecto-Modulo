document.addEventListener("DOMContentLoaded", async () => {
    const gate = document.getElementById("seller-gate");
    const form = document.getElementById("product-form");
    const status = document.getElementById("seller-status");
    const listing = document.getElementById("seller-products");
    const listingSection = listing.closest(".seller-listing");
    const preview = document.getElementById("image-preview");
    const imagesInput = form.elements.images;
    let previewUrls = [];

    function renderSellerProduct(product) {
        const card = MotorCrew.productCard(product);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "btn btn-danger seller-delete-product";
        remove.textContent = "Eliminar producto";
        remove.addEventListener("click", async () => {
            if (!window.confirm(`¿Eliminar permanentemente "${product.name}" del catálogo? Los pedidos anteriores conservarán el producto en su historial.`)) return;
            remove.disabled = true;
            status.textContent = `Eliminando "${product.name}"...`;
            try {
                const { message } = await MotorCrew.request(`/api/products/${encodeURIComponent(product.id)}`, { method: "DELETE" });
                card.remove();
                status.textContent = message;
                if (!listing.children.length) listing.textContent = "Aún no has publicado productos.";
            } catch (error) {
                status.textContent = error.message;
                remove.disabled = false;
            }
        });
        card.append(remove);
        return card;
    }

    function renderPreviews() {
        previewUrls.forEach(URL.revokeObjectURL);
        previewUrls = [];
        preview.replaceChildren();
        [...imagesInput.files].slice(0, 5).forEach(file => {
            const image = document.createElement("img");
            image.alt = `Vista previa: ${file.name}`;
            image.src = URL.createObjectURL(file);
            previewUrls.push(image.src);
            preview.append(image);
        });
    }
    imagesInput.addEventListener("change", renderPreviews);

    try {
        const { user } = await MotorCrew.request("/api/auth/me");
        if (!["SELLER", "BOTH"].includes(user.role)) {
            gate.textContent = "Tu cuenta está configurada como compradora. Crea una cuenta de vendedor para publicar productos.";
            gate.append(document.createTextNode(" "));
            const link = document.createElement("a");
            link.href = "login.html";
            link.textContent = "Cambiar de cuenta";
            gate.append(link);
            return;
        }
        gate.textContent = `Sesión iniciada como ${user.name}.`;
        listingSection.hidden = false;
        form.hidden = false;
        const { products } = await MotorCrew.request("/api/seller/products");
        products.forEach(product => listing.append(renderSellerProduct(product)));
        if (!products.length) listing.textContent = "Aún no has publicado productos.";
    } catch (error) {
        if (error.status === 401) {
            gate.replaceChildren(document.createTextNode("Inicia sesión con un perfil de vendedor para publicar productos. "));
            const link = document.createElement("a");
            link.href = `login.html?next=${encodeURIComponent("publicar.html")}`;
            link.textContent = "Iniciar sesión";
            gate.append(link);
        } else {
            gate.textContent = error.message;
        }
        return;
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "Publicando producto...";
        const body = new FormData(form);
        try {
            const { product } = await MotorCrew.request("/api/products", { method: "POST", body });
            status.textContent = "Producto publicado. Ya está disponible en el catálogo.";
            form.reset();
            renderPreviews();
            listing.prepend(renderSellerProduct(product));
        } catch (error) {
            status.textContent = error.message;
        }
    });
});
