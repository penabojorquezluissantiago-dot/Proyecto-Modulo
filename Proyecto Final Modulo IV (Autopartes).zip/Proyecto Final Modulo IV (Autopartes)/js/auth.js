document.addEventListener("DOMContentLoaded", () => {
    const loginTab = document.getElementById("login-tab");
    const registerTab = document.getElementById("register-tab");
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const status = document.getElementById("auth-status");

    function destination(fallback) {
        const next = new URLSearchParams(location.search).get("next");
        if (next) {
            const target = new URL(next, location.href);
            if (target.origin === location.origin && target.pathname.endsWith(".html")) {
                return `${target.pathname}${target.search}${target.hash}`;
            }
        }
        return fallback;
    }

    function showForm(isRegister) {
        loginForm.hidden = isRegister;
        registerForm.hidden = !isRegister;
        loginTab.classList.toggle("is-active", !isRegister);
        registerTab.classList.toggle("is-active", isRegister);
        loginTab.setAttribute("aria-selected", String(!isRegister));
        registerTab.setAttribute("aria-selected", String(isRegister));
        status.textContent = "";
    }
    loginTab.addEventListener("click", () => showForm(false));
    registerTab.addEventListener("click", () => showForm(true));

    loginForm.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "Iniciando sesión...";
        const form = new FormData(loginForm);
        try {
            const { user } = await MotorCrew.request("/api/auth/login", { method: "POST", body: JSON.stringify(Object.fromEntries(form)) });
            MotorCrew.setActiveAccount(user);
            window.location.href = user.role === "ADMIN" ? "admin.html" : destination("index.html");
        } catch (error) {
            status.textContent = error.message;
        }
    });
    registerForm.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "Creando cuenta...";
        try {
            const { user } = await MotorCrew.request("/api/auth/register", { method: "POST", body: JSON.stringify(Object.fromEntries(new FormData(registerForm))) });
            MotorCrew.setActiveAccount(user);
            window.location.href = destination(user.role === "SELLER" ? "publicar.html" : "index.html");
        } catch (error) {
            status.textContent = error.message;
        }
    });
});
