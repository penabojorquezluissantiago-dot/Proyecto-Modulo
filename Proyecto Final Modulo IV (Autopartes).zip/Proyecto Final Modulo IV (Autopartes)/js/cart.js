document.addEventListener("DOMContentLoaded", async () => {
    const list = document.getElementById("cart-items");
    const summary = document.getElementById("cart-summary");
    const status = document.getElementById("cart-status");

    function renderSummary(items) {
        const subtotal = items.reduce((total, item) => total + item.product.price * item.quantity, 0);
        summary.replaceChildren();
        const title = document.createElement("h2");
        title.textContent = "Resumen";
        const line = document.createElement("p");
        line.className = "summary-line";
        line.innerHTML = `<span>Productos (${items.reduce((count, item) => count + item.quantity, 0)})</span><strong>${MotorCrew.currency.format(subtotal)}</strong>`;
        const note = document.createElement("p");
        note.className = "checkout-disclaimer";
        note.textContent = "El IVA y el envío se calculan y muestran antes de confirmar tu pedido.";
        const checkout = document.createElement("a");
        checkout.className = "btn btn-primary";
        checkout.textContent = "Continuar compra";
        checkout.setAttribute("aria-disabled", String(items.length === 0));
        if (items.length) {
            checkout.href = "checkout.html";
        } else {
            checkout.tabIndex = -1;
            checkout.classList.add("is-disabled");
        }
        summary.append(title, line, note, checkout);
    }

    function renderItems(items) {
        list.replaceChildren();
        if (!items.length) {
            const empty = document.createElement("p");
            empty.className = "store-message empty-state";
            empty.textContent = "Tu carrito está vacío. Explora el catálogo para encontrar lo que necesitas.";
            const link = document.createElement("a");
            link.href = "catalogo.html";
            link.className = "btn btn-glass";
            link.textContent = "Ir al catálogo";
            list.append(empty, link);
            renderSummary(items);
            return;
        }
        items.forEach(item => {
            const row = document.createElement("article");
            row.className = "cart-item glass-panel";
            const image = document.createElement("img");
            image.src = item.product.images[0] || "";
            image.alt = item.product.name;
            image.hidden = !item.product.images.length;
            const content = document.createElement("div");
            content.className = "cart-item-info";
            const title = document.createElement("h2");
            title.textContent = item.product.name;
            const price = document.createElement("p");
            price.className = "product-price";
            price.textContent = MotorCrew.currency.format(item.product.price);
            const controls = document.createElement("div");
            controls.className = "cart-item-controls";
            const quantityLabel = document.createElement("label");
            quantityLabel.textContent = "Cantidad ";
            const quantity = document.createElement("input");
            quantity.type = "number";
            quantity.min = "1";
            quantity.max = String(Math.max(1, Math.min(100, item.product.stock)));
            quantity.value = String(item.quantity);
            quantity.setAttribute("aria-label", `Cantidad de ${item.product.name}`);
            quantity.addEventListener("change", async () => {
                status.textContent = "Actualizando carrito...";
                try {
                    await MotorCrew.request(`/api/cart/${encodeURIComponent(item.product.id)}`, {
                        method: "PUT",
                        body: JSON.stringify({ quantity: Number(quantity.value) })
                    });
                    window.dispatchEvent(new Event("motorcrew:cart-updated"));
                    await loadCart();
                } catch (error) {
                    status.textContent = error.message;
                    quantity.value = String(item.quantity);
                }
            });
            quantityLabel.append(quantity);
            const remove = document.createElement("button");
            remove.type = "button";
            remove.className = "text-button";
            remove.textContent = "Quitar";
            remove.addEventListener("click", async () => {
                status.textContent = "Quitando producto...";
                try {
                    await MotorCrew.request(`/api/cart/${encodeURIComponent(item.product.id)}`, { method: "DELETE" });
                    window.dispatchEvent(new Event("motorcrew:cart-updated"));
                    await loadCart();
                    status.textContent = "Producto eliminado del carrito.";
                } catch (error) {
                    status.textContent = error.message;
                }
            });
            controls.append(quantityLabel, remove);
            content.append(title, price, controls);
            row.append(image, content);
            list.append(row);
        });
        renderSummary(items);
    }

    async function loadCart() {
        try {
            const { items } = await MotorCrew.request("/api/cart");
            renderItems(items);
        } catch (error) {
            status.textContent = error.message;
            if (error.status === 401) location.href = `login.html?next=${encodeURIComponent("carrito.html")}`;
        }
    }

    await loadCart();
});
