document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("catalog-products");
    const search = document.getElementById("product-search");
    const category = document.getElementById("category-filter");
    const status = document.getElementById("catalog-status");
    let timer;
    const initialCategory = new URLSearchParams(location.search).get("category");
    if ([...category.options].some(option => option.value === initialCategory)) category.value = initialCategory;

    async function loadProducts() {
        const params = new URLSearchParams();
        if (search.value.trim()) params.set("search", search.value.trim());
        if (category.value) params.set("category", category.value);
        const query = params.toString();
        container.replaceChildren();
        const loading = document.createElement("p");
        loading.className = "store-message";
        loading.textContent = "Buscando productos...";
        container.append(loading);
        try {
            const { products } = await MotorCrew.request(`/api/products${query ? `?${query}` : ""}`);
            container.replaceChildren();
            products.forEach(product => container.append(MotorCrew.productCard(product)));
            status.textContent = products.length ? `${products.length} producto(s) disponible(s)` : "No encontramos productos. Prueba otra búsqueda o vuelve más tarde.";
        } catch (error) {
            status.textContent = error.message;
        }
    }

    search.addEventListener("input", () => {
        clearTimeout(timer);
        timer = setTimeout(loadProducts, 250);
    });
    category.addEventListener("change", loadProducts);
    loadProducts();
});
