const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
require("dotenv").config({ path: path.resolve(__dirname, "..", ".env") });

const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");

const app = express();
const port = Number(process.env.PORT || 3000);
const webRoot = path.resolve(__dirname, "..", "..");
const uploadRoot = path.join(__dirname, "..", "uploads");
const databasePath = process.env.DATABASE_PATH
    ? path.resolve(__dirname, "..", process.env.DATABASE_PATH)
    : path.join(__dirname, "..", "data", "motorcrew.sqlite");
const jwtSecret = process.env.JWT_SECRET;
const adminEmail = "main@motorcrew.admin";
const initialAdminPassword = process.env.ADMIN_INITIAL_PASSWORD;
const allowedRoles = new Set(["BUYER", "SELLER", "BOTH"]);
const allowedCategories = new Set(["Motor y escape", "Frenos y suspensión", "Accesorios", "Herramientas", "Otros"]);
const taxRatePercent = 16;
const shippingFeeCents = 14900;
const freeShippingThresholdCents = 150000;
const imageTypes = new Map([
    ["image/jpeg", ".jpg"],
    ["image/png", ".png"],
    ["image/webp", ".webp"]
]);

if (!jwtSecret || jwtSecret.length < 32) {
    throw new Error("Configura JWT_SECRET con al menos 32 caracteres en server/.env.");
}

fs.mkdirSync(uploadRoot, { recursive: true });
fs.mkdirSync(path.dirname(databasePath), { recursive: true });
const database = new DatabaseSync(databasePath);
database.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL COLLATE NOCASE UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('BUYER', 'SELLER', 'BOTH')),
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id INTEGER NOT NULL REFERENCES users(id),
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        price_cents INTEGER NOT NULL CHECK (price_cents > 0),
        stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS products_seller_idx ON products(seller_id);
    CREATE INDEX IF NOT EXISTS products_category_active_idx ON products(category, is_active);
    CREATE TABLE IF NOT EXISTS product_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        url TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cart_items (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 100),
        PRIMARY KEY (user_id, product_id)
    );
    CREATE TABLE IF NOT EXISTS favorites (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        PRIMARY KEY (user_id, product_id)
    );
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        buyer_id INTEGER REFERENCES users(id),
        subtotal_cents INTEGER NOT NULL DEFAULT 0 CHECK (subtotal_cents >= 0),
        tax_cents INTEGER NOT NULL DEFAULT 0 CHECK (tax_cents >= 0),
        shipping_cents INTEGER NOT NULL DEFAULT 0 CHECK (shipping_cents >= 0),
        total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
        shipping_address TEXT,
        status TEXT NOT NULL DEFAULT 'PENDING',
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS orders_buyer_created_idx ON orders(buyer_id, created_at);
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents > 0),
        product_name TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS order_items_product_idx ON order_items(product_id);
    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id),
        rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        UNIQUE (product_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS reviews_product_created_idx ON reviews(product_id, created_at);
    CREATE TABLE IF NOT EXISTS review_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
        url TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS site_admins (
        user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE TABLE IF NOT EXISTS auth_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        event_type TEXT NOT NULL CHECK (event_type IN ('LOGIN', 'REGISTER')),
        occurred_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS auth_events_user_time_idx ON auth_events(user_id, occurred_at);
`);

const userColumns = new Set(database.prepare("PRAGMA table_info(users)").all().map(column => column.name));
if (!userColumns.has("session_version")) database.exec("ALTER TABLE users ADD COLUMN session_version INTEGER NOT NULL DEFAULT 0");

if (initialAdminPassword) {
    if (initialAdminPassword.length < 12 || initialAdminPassword.length > 72) {
        throw new Error("ADMIN_INITIAL_PASSWORD debe tener entre 12 y 72 caracteres.");
    }
    let admin = database.prepare("SELECT id FROM users WHERE email = ? COLLATE NOCASE").get(adminEmail);
    if (!admin) {
        const passwordHash = bcrypt.hashSync(initialAdminPassword, 12);
        const result = database.prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'BUYER')").run("Administrador MotorCrew", adminEmail, passwordHash);
        admin = { id: Number(result.lastInsertRowid) };
    } else if (!database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(admin.id)) {
        throw new Error("El correo reservado de administración ya existe como cuenta normal; revisa server/data antes de aprovisionar el administrador.");
    }
    database.prepare("INSERT OR IGNORE INTO site_admins (user_id) VALUES (?)").run(admin.id);
} else {
    console.warn("Cuenta admin no aprovisionada. Define ADMIN_INITIAL_PASSWORD (mínimo 12 caracteres) para habilitarla.");
}

const orderColumns = new Set(database.prepare("PRAGMA table_info(orders)").all().map(column => column.name));
for (const [column, definition] of [
    ["subtotal_cents", "INTEGER NOT NULL DEFAULT 0"],
    ["tax_cents", "INTEGER NOT NULL DEFAULT 0"],
    ["shipping_cents", "INTEGER NOT NULL DEFAULT 0"],
    ["shipping_address", "TEXT"]
]) {
    if (!orderColumns.has(column)) database.exec(`ALTER TABLE orders ADD COLUMN ${column} ${definition}`);
}
database.exec("UPDATE orders SET subtotal_cents = total_cents WHERE subtotal_cents = 0 AND total_cents > 0");
const orderItemColumns = new Set(database.prepare("PRAGMA table_info(order_items)").all().map(column => column.name));
if (!orderItemColumns.has("product_name")) database.exec("ALTER TABLE order_items ADD COLUMN product_name TEXT NOT NULL DEFAULT ''");
database.exec(`
    UPDATE order_items
    SET product_name = (SELECT name FROM products WHERE products.id = order_items.product_id)
    WHERE product_name = '' AND product_id IS NOT NULL
`);
const buyerIdColumn = database.prepare("PRAGMA table_info(orders)").all().find(column => column.name === "buyer_id");
const productIdColumn = database.prepare("PRAGMA table_info(order_items)").all().find(column => column.name === "product_id");
if (buyerIdColumn?.notnull || productIdColumn?.notnull) {
    database.exec(`
        PRAGMA foreign_keys = OFF;
        BEGIN IMMEDIATE;
        CREATE TABLE orders_for_deletion_migration (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            buyer_id INTEGER REFERENCES users(id),
            subtotal_cents INTEGER NOT NULL DEFAULT 0 CHECK (subtotal_cents >= 0),
            tax_cents INTEGER NOT NULL DEFAULT 0 CHECK (tax_cents >= 0),
            shipping_cents INTEGER NOT NULL DEFAULT 0 CHECK (shipping_cents >= 0),
            total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
            shipping_address TEXT,
            status TEXT NOT NULL DEFAULT 'PENDING',
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
        );
        INSERT INTO orders_for_deletion_migration
            (id, buyer_id, subtotal_cents, tax_cents, shipping_cents, total_cents, shipping_address, status, created_at)
        SELECT id, buyer_id, subtotal_cents, tax_cents, shipping_cents, total_cents, shipping_address, status, created_at
        FROM orders;
        CREATE TABLE order_items_for_deletion_migration (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL REFERENCES orders_for_deletion_migration(id) ON DELETE CASCADE,
            product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
            quantity INTEGER NOT NULL CHECK (quantity > 0),
            unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents > 0),
            product_name TEXT NOT NULL DEFAULT ''
        );
        INSERT INTO order_items_for_deletion_migration
            (id, order_id, product_id, quantity, unit_price_cents, product_name)
        SELECT id, order_id, product_id, quantity, unit_price_cents, product_name FROM order_items;
        DROP INDEX IF EXISTS orders_buyer_created_idx;
        DROP INDEX IF EXISTS order_items_product_idx;
        DROP TABLE order_items;
        DROP TABLE orders;
        ALTER TABLE orders_for_deletion_migration RENAME TO orders;
        ALTER TABLE order_items_for_deletion_migration RENAME TO order_items;
        CREATE INDEX orders_buyer_created_idx ON orders(buyer_id, created_at);
        CREATE INDEX order_items_product_idx ON order_items(product_id);
        COMMIT;
        PRAGMA foreign_keys = ON;
    `);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use((req, _res, next) => {
    req.body = req.body || {};
    next();
});
app.use("/uploads", express.static(uploadRoot, { dotfiles: "deny", index: false, maxAge: "1d" }));

const upload = multer({
    storage: multer.diskStorage({
        destination: uploadRoot,
        filename: (_req, file, callback) => callback(null, `${crypto.randomUUID()}${imageTypes.get(file.mimetype) || ".img"}`)
    }),
    limits: { fileSize: 5 * 1024 * 1024, files: 5 },
    fileFilter: (_req, file, callback) => {
        if (!imageTypes.has(file.mimetype)) {
            callback(new Error("Solo se aceptan imágenes JPG, PNG o WebP."));
            return;
        }
        callback(null, true);
    }
});

function sendError(res, status, message) {
    return res.status(status).json({ error: message });
}

function safeUser(user) {
    const isAdmin = Boolean(database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(user.id));
    return { id: user.id, name: user.name, email: user.email, role: isAdmin ? "ADMIN" : user.role, createdAt: user.created_at };
}

function issueSession(res, user) {
    const token = jwt.sign({ sub: String(user.id), sessionVersion: user.sessionVersion || 0 }, jwtSecret, { expiresIn: "7d" });
    const cookieOptions = {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: "/"
    };
    res.cookie("motorcrew_session", token, cookieOptions);
    res.cookie(`motorcrew_session_${user.id}`, token, cookieOptions);
}

function findUserById(id) {
    return database.prepare("SELECT id, name, email, password_hash, role, created_at, session_version AS sessionVersion FROM users WHERE id = ?").get(id);
}

function authenticate(req, res, next) {
    const accountId = req.get("X-MotorCrew-Account");
    if (accountId !== undefined && !/^[1-9]\d{0,14}$/.test(accountId)) {
        return sendError(res, 400, "La sesión seleccionada no es válida.");
    }
    const sessionCookieName = accountId ? `motorcrew_session_${accountId}` : "motorcrew_session";
    const token = req.cookies?.[sessionCookieName];
    if (!token) return sendError(res, 401, "Inicia sesión para continuar.");
    try {
        const payload = jwt.verify(token, jwtSecret);
        const user = findUserById(Number(payload.sub));
        if (!user || (accountId && String(user.id) !== accountId) || (payload.sessionVersion || 0) !== user.sessionVersion) {
            return sendError(res, 401, "La sesión ya no es válida.");
        }
        if (database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(user.id)) user.role = "ADMIN";
        req.user = user;
        req.sessionCookieName = sessionCookieName;
        next();
    } catch (error) {
        if (error instanceof jwt.JsonWebTokenError || error instanceof jwt.TokenExpiredError) {
            return sendError(res, 401, "La sesión ya no es válida. Inicia sesión de nuevo.");
        }
        next(error);
    }
}

function requireRole(...roles) {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) return sendError(res, 403, "Tu tipo de cuenta no permite realizar esta acción.");
        next();
    };
}

function requireAdmin(req, res, next) {
    if (req.user.role !== "ADMIN") return sendError(res, 403, "Esta sección está reservada para la administración.");
    next();
}

function parseProductInput(body) {
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const category = typeof body.category === "string" ? body.category : "";
    const price = Number(body.price);
    const stock = Number(body.stock);
    if (name.length < 3 || name.length > 100) throw new Error("El nombre debe tener entre 3 y 100 caracteres.");
    if (description.length < 10 || description.length > 3000) throw new Error("La descripción debe tener entre 10 y 3000 caracteres.");
    if (!allowedCategories.has(category)) throw new Error("Selecciona una categoría válida.");
    if (!Number.isFinite(price) || price <= 0 || price > 10000000 || Math.round(price * 100) < 1) throw new Error("Ingresa un precio válido.");
    if (!Number.isInteger(stock) || stock < 1 || stock > 100000) throw new Error("El inventario debe ser un entero entre 1 y 100000.");
    return { name, description, category, priceCents: Math.round(price * 100), stock };
}

async function isValidImage(file) {
    const handle = await fs.promises.open(file.path, "r");
    try {
        const header = Buffer.alloc(12);
        const { bytesRead } = await handle.read(header, 0, header.length, 0);
        if (file.mimetype === "image/jpeg") return bytesRead >= 3 && header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff;
        if (file.mimetype === "image/png") return bytesRead >= 8 && header.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        return file.mimetype === "image/webp" && bytesRead >= 12 &&
            header.toString("ascii", 0, 4) === "RIFF" && header.toString("ascii", 8, 12) === "WEBP";
    } finally {
        await handle.close();
    }
}

function transaction(operation) {
    database.exec("BEGIN IMMEDIATE");
    try {
        const result = operation();
        database.exec("COMMIT");
        return result;
    } catch (error) {
        database.exec("ROLLBACK");
        throw error;
    }
}

function getUploadedFilePaths(urls) {
    return urls
        .filter(url => typeof url === "string" && url.startsWith("/uploads/"))
        .map(url => path.join(uploadRoot, path.basename(url)));
}

async function removeUploadedFiles(urls) {
    await Promise.all(getUploadedFilePaths(urls).map(filePath => fs.promises.rm(filePath, { force: true })));
}

const productSelect = `
    SELECT p.id, p.name, p.description, p.category, p.price_cents AS priceCents,
           p.stock, p.is_active AS isActive, p.created_at AS createdAt, p.seller_id AS sellerId,
           u.name AS sellerName,
           (SELECT url FROM product_images WHERE product_id = p.id ORDER BY id LIMIT 1) AS imageUrl,
           COALESCE((SELECT AVG(rating) FROM reviews WHERE product_id = p.id), 0) AS averageRating,
           (SELECT COUNT(*) FROM reviews WHERE product_id = p.id) AS reviewCount
    FROM products p JOIN users u ON u.id = p.seller_id
`;

function publicProduct(product, images) {
    return {
        id: product.id,
        name: product.name,
        description: product.description,
        category: product.category,
        price: product.priceCents / 100,
        stock: product.stock,
        createdAt: product.createdAt,
        seller: { id: product.sellerId, name: product.sellerName },
        images: images || (product.imageUrl ? [product.imageUrl] : []),
        averageRating: product.averageRating || 0,
        reviewCount: product.reviewCount || 0
    };
}

function mapOrders(rows) {
    const orders = new Map();
    rows.forEach(row => {
        let order = orders.get(row.id);
        if (!order) {
            order = {
                id: row.id,
                orderNumber: row.buyerOrderNumber ?? null,
                buyer: row.buyerId ? { id: row.buyerId, name: row.buyerName, email: row.buyerEmail } : null,
                status: row.status,
                subtotal: row.subtotalCents / 100,
                tax: row.taxCents / 100,
                shipping: row.shippingCents / 100,
                total: row.totalCents / 100,
                shippingAddress: row.shippingAddress ? JSON.parse(row.shippingAddress) : null,
                createdAt: row.createdAt,
                items: []
            };
            orders.set(row.id, order);
        }
        if (row.productName) {
            order.items.push({ name: row.productName, quantity: row.quantity, price: row.unitPriceCents / 100 });
        }
    });
    return [...orders.values()];
}

function parseShippingAddress(body) {
    const address = {};
    for (const [field, label, min, max] of [
        ["name", "El nombre", 2, 100],
        ["email", "El correo", 3, 254],
        ["phone", "El teléfono", 8, 20],
        ["street", "La calle y número", 4, 160],
        ["neighborhood", "La colonia", 2, 100],
        ["postalCode", "El código postal", 5, 5],
        ["city", "La ciudad", 2, 100],
        ["state", "El estado", 2, 100]
    ]) {
        const value = typeof body?.[field] === "string" ? body[field].trim() : "";
        if (value.length < min || value.length > max) throw Object.assign(new Error(`${label} no es válido.`), { status: 400 });
        address[field] = value;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address.email)) throw Object.assign(new Error("Ingresa un correo válido."), { status: 400 });
    if (!/^[0-9]{5}$/.test(address.postalCode)) throw Object.assign(new Error("El código postal debe tener 5 dígitos."), { status: 400 });
    if (!/^[+()\d\s-]+$/.test(address.phone)) throw Object.assign(new Error("Ingresa un teléfono válido."), { status: 400 });
    const references = typeof body.references === "string" ? body.references.trim() : "";
    if (references.length > 300) throw Object.assign(new Error("Las referencias no pueden superar 300 caracteres."), { status: 400 });
    address.references = references;
    return address;
}

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.post("/api/auth/register", async (req, res, next) => {
    try {
        const name = typeof req.body.name === "string" ? req.body.name.trim() : "";
        const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : "";
        const password = typeof req.body.password === "string" ? req.body.password : "";
        const role = typeof req.body.role === "string" ? req.body.role : "BUYER";
        if (name.length < 2 || name.length > 80) return sendError(res, 400, "El nombre debe tener entre 2 y 80 caracteres.");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return sendError(res, 400, "Ingresa un correo válido.");
        if (email === adminEmail) return sendError(res, 403, "Ese correo está reservado para la administración.");
        if (password.length < 8 || password.length > 72) return sendError(res, 400, "La contraseña debe tener entre 8 y 72 caracteres.");
        if (!allowedRoles.has(role)) return sendError(res, 400, "Selecciona un perfil válido.");
        const passwordHash = await bcrypt.hash(password, 12);
        const result = database.prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)").run(name, email, passwordHash, role);
        const user = findUserById(Number(result.lastInsertRowid));
        database.prepare("INSERT INTO auth_events (user_id, event_type) VALUES (?, 'REGISTER')").run(user.id);
        issueSession(res, user);
        res.status(201).json({ user: safeUser(user) });
    } catch (error) {
        if (error.errcode === 2067 || error.message.includes("UNIQUE constraint failed: users.email")) {
            return sendError(res, 409, "Ya existe una cuenta con ese correo.");
        }
        next(error);
    }
});

app.post("/api/auth/login", async (req, res, next) => {
    try {
        const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : "";
        const password = typeof req.body.password === "string" ? req.body.password : "";
        if (email === adminEmail && !database.prepare("SELECT 1 FROM site_admins a JOIN users u ON u.id = a.user_id WHERE u.email = ? COLLATE NOCASE").get(adminEmail)) {
            return sendError(res, 403, "La cuenta de administración todavía no está configurada.");
        }
        const user = database.prepare("SELECT id, name, email, password_hash, role, created_at, session_version AS sessionVersion FROM users WHERE email = ? COLLATE NOCASE").get(email);
        if (!user || !(await bcrypt.compare(password, user.password_hash))) {
            return sendError(res, 401, "Correo o contraseña incorrectos.");
        }
        if (database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(user.id)) user.role = "ADMIN";
        database.prepare("INSERT INTO auth_events (user_id, event_type) VALUES (?, 'LOGIN')").run(user.id);
        issueSession(res, user);
        res.json({ user: safeUser(user) });
    } catch (error) {
        next(error);
    }
});

app.post("/api/auth/logout", (_req, res) => {
    const options = { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/" };
    const accountId = _req.get("X-MotorCrew-Account");
    res.clearCookie("motorcrew_session", options);
    if (accountId && /^[1-9]\d{0,14}$/.test(accountId)) res.clearCookie(`motorcrew_session_${accountId}`, options);
    res.json({ message: "Sesión cerrada." });
});

app.get("/api/auth/me", authenticate, (req, res) => {
    if (!req.cookies?.[`motorcrew_session_${req.user.id}`]) issueSession(res, req.user);
    res.json({ user: safeUser(req.user) });
});

app.put("/api/auth/me", authenticate, async (req, res, next) => {
    try {
        const name = typeof req.body.name === "string" ? req.body.name.trim() : "";
        const currentPassword = typeof req.body.currentPassword === "string" ? req.body.currentPassword : "";
        const newPassword = typeof req.body.newPassword === "string" ? req.body.newPassword : "";
        const changesName = req.body.name !== undefined;
        const changesPassword = req.body.newPassword !== undefined;
        if (!changesName && !changesPassword) return sendError(res, 400, "Indica el nuevo nombre o contraseña.");
        if (changesName && (name.length < 2 || name.length > 80)) return sendError(res, 400, "El nombre debe tener entre 2 y 80 caracteres.");
        if (changesPassword) {
            if (!currentPassword || !(await bcrypt.compare(currentPassword, req.user.password_hash))) {
                return sendError(res, 401, "La contraseña actual no es correcta.");
            }
            if (newPassword.length < 8 || newPassword.length > 72) return sendError(res, 400, "La nueva contraseña debe tener entre 8 y 72 caracteres.");
        }
        if (changesPassword) {
            const passwordHash = await bcrypt.hash(newPassword, 12);
            database.prepare(`
                UPDATE users
                SET name = ?, password_hash = ?, session_version = session_version + 1
                WHERE id = ?
            `).run(changesName ? name : req.user.name, passwordHash, req.user.id);
            const user = findUserById(req.user.id);
            issueSession(res, user);
            return res.json({ user: safeUser(user), message: "Tu cuenta fue actualizada. Las otras sesiones se cerraron por seguridad." });
        }
        database.prepare("UPDATE users SET name = ? WHERE id = ?").run(name, req.user.id);
        const user = findUserById(req.user.id);
        res.json({ user: safeUser(user), message: "Tu nombre fue actualizado." });
    } catch (error) {
        next(error);
    }
});

app.get("/api/auth/sessions", authenticate, (req, res) => {
    const sessions = Object.entries(req.cookies || {})
        .filter(([name]) => /^motorcrew_session_[1-9]\d{0,14}$/.test(name))
        .flatMap(([name, token]) => {
            try {
                const payload = jwt.verify(token, jwtSecret);
                const user = findUserById(Number(payload.sub));
                const cookieUserId = name.slice("motorcrew_session_".length);
                if (!user || String(user.id) !== cookieUserId || (payload.sessionVersion || 0) !== user.sessionVersion) return [];
                return [{ ...safeUser(user), isCurrent: user.id === req.user.id }];
            } catch (error) {
                if (error instanceof jwt.JsonWebTokenError || error instanceof jwt.TokenExpiredError) return [];
                throw error;
            }
        })
        .sort((left, right) => left.name.localeCompare(right.name, "es"));
    res.json({ sessions });
});

app.delete("/api/auth/me", authenticate, async (req, res, next) => {
    try {
        if (req.user.role === "ADMIN") return sendError(res, 403, "La cuenta de administración no se puede eliminar desde el sitio.");
        const password = typeof req.body.password === "string" ? req.body.password : "";
        if (!password || !(await bcrypt.compare(password, req.user.password_hash))) {
            return sendError(res, 401, "La contraseña no es correcta.");
        }
        const imageUrls = database.prepare(`
            SELECT pi.url FROM product_images pi
            JOIN products p ON p.id = pi.product_id
            WHERE p.seller_id = ?
            UNION
            SELECT ri.url FROM review_images ri
            JOIN reviews r ON r.id = ri.review_id
            LEFT JOIN products p ON p.id = r.product_id
            WHERE r.user_id = ? OR p.seller_id = ?
        `).all(req.user.id, req.user.id, req.user.id).map(image => image.url);
        transaction(() => {
            database.prepare(`
                UPDATE order_items
                SET product_name = COALESCE(NULLIF(product_name, ''), (
                    SELECT name FROM products WHERE products.id = order_items.product_id
                )), product_id = NULL
                WHERE product_id IN (SELECT id FROM products WHERE seller_id = ?)
            `).run(req.user.id);
            database.prepare("UPDATE orders SET buyer_id = NULL, shipping_address = NULL WHERE buyer_id = ?").run(req.user.id);
            database.prepare("DELETE FROM reviews WHERE user_id = ?").run(req.user.id);
            database.prepare("DELETE FROM products WHERE seller_id = ?").run(req.user.id);
            database.prepare("DELETE FROM users WHERE id = ?").run(req.user.id);
        });
        await removeUploadedFiles(imageUrls);
        res.clearCookie("motorcrew_session", {
            httpOnly: true,
            sameSite: "lax",
            secure: process.env.NODE_ENV === "production",
            path: "/"
        });
        res.clearCookie(`motorcrew_session_${req.user.id}`, {
            httpOnly: true,
            sameSite: "lax",
            secure: process.env.NODE_ENV === "production",
            path: "/"
        });
        res.json({ message: "Tu cuenta y tus datos personales fueron eliminados. Los pedidos anteriores se conservaron anonimizados." });
    } catch (error) {
        next(error);
    }
});

app.get("/api/products", (req, res, next) => {
    try {
        const filters = ["p.is_active = 1", "p.stock > 0"];
        const params = [];
        if (req.query.category !== undefined) {
            if (typeof req.query.category !== "string" || !allowedCategories.has(req.query.category)) {
                return sendError(res, 400, "La categoría seleccionada no es válida.");
            }
            filters.push("p.category = ?");
            params.push(req.query.category);
        }
        if (req.query.search !== undefined && typeof req.query.search !== "string") {
            return sendError(res, 400, "El término de búsqueda no es válido.");
        }
        if (typeof req.query.search === "string" && req.query.search.trim()) {
            const search = req.query.search.trim();
            if (search.length > 100) return sendError(res, 400, "La búsqueda no puede superar 100 caracteres.");
            const pattern = `%${search.replace(/[\\%_]/g, "\\$&")}%`;
            filters.push("(p.name LIKE ? ESCAPE '\\' COLLATE NOCASE OR p.description LIKE ? ESCAPE '\\' COLLATE NOCASE)");
            params.push(pattern, pattern);
        }
        const products = database.prepare(`${productSelect} WHERE ${filters.join(" AND ")} ORDER BY p.created_at DESC`).all(...params);
        res.json({ products: products.map(product => publicProduct(product)) });
    } catch (error) {
        next(error);
    }
});

app.get("/api/products/:id", (req, res, next) => {
    try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id < 1) return sendError(res, 400, "Producto inválido.");
        const row = database.prepare(`${productSelect} WHERE p.id = ? AND p.is_active = 1`).get(id);
        if (!row) return sendError(res, 404, "No encontramos ese producto.");
        const images = database.prepare("SELECT url FROM product_images WHERE product_id = ? ORDER BY id").all(id).map(image => image.url);
        const reviews = database.prepare(`
            SELECT r.id, r.rating, r.comment, r.created_at AS createdAt, u.name AS buyerName
            FROM reviews r JOIN users u ON u.id = r.user_id
            WHERE r.product_id = ? ORDER BY r.created_at DESC
        `).all(id);
        reviews.forEach(review => {
            review.images = database.prepare("SELECT url FROM review_images WHERE review_id = ? ORDER BY id").all(review.id).map(image => image.url);
        });
        res.json({ product: publicProduct(row, images), reviews });
    } catch (error) {
        next(error);
    }
});

app.post("/api/products", authenticate, requireRole("SELLER", "BOTH"), upload.array("images", 5), async (req, res, next) => {
    const files = req.files || [];
    try {
        const validImages = await Promise.all(files.map(isValidImage));
        if (validImages.some(isValid => !isValid)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 400, "Uno o más archivos no contienen una imagen JPG, PNG o WebP válida.");
        }
        const input = parseProductInput(req.body);
        if (files.length === 0) return sendError(res, 400, "Agrega al menos una foto del producto.");
        const productId = transaction(() => {
            const inserted = database.prepare(`
                INSERT INTO products (seller_id, name, description, category, price_cents, stock)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run(req.user.id, input.name, input.description, input.category, input.priceCents, input.stock);
            const id = Number(inserted.lastInsertRowid);
            const addImage = database.prepare("INSERT INTO product_images (product_id, url) VALUES (?, ?)");
            files.forEach(file => addImage.run(id, `/uploads/${file.filename}`));
            return id;
        });
        const product = database.prepare(`${productSelect} WHERE p.id = ?`).get(productId);
        res.status(201).json({ product: publicProduct(product) });
    } catch (error) {
        await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
        if (typeof error.message === "string" && (
            error.message.startsWith("El nombre") || error.message.startsWith("La descripción") ||
            error.message.startsWith("Selecciona") || error.message.startsWith("Ingresa un precio") ||
            error.message.startsWith("El inventario")
        )) return sendError(res, 400, error.message);
        next(error);
    }
});

app.get("/api/seller/products", authenticate, requireRole("SELLER", "BOTH"), (req, res, next) => {
    try {
        const products = database.prepare(`${productSelect} WHERE p.seller_id = ? ORDER BY p.created_at DESC`).all(req.user.id);
        res.json({ products: products.map(product => publicProduct(product)) });
    } catch (error) {
        next(error);
    }
});

app.delete("/api/products/:id", authenticate, requireRole("SELLER", "BOTH"), async (req, res, next) => {
    try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id < 1) return sendError(res, 400, "Producto inválido.");
        const imageUrls = [
            ...database.prepare("SELECT url FROM product_images WHERE product_id = ?").all(id).map(image => image.url),
            ...database.prepare(`
                SELECT ri.url FROM review_images ri
                JOIN reviews r ON r.id = ri.review_id WHERE r.product_id = ?
            `).all(id).map(image => image.url)
        ];
        transaction(() => {
            const product = database.prepare("SELECT id, name FROM products WHERE id = ? AND seller_id = ?").get(id, req.user.id);
            if (!product) throw Object.assign(new Error("No encontramos ese producto en tus publicaciones."), { status: 404 });
            database.prepare(`
                UPDATE order_items SET product_name = COALESCE(NULLIF(product_name, ''), ?), product_id = NULL
                WHERE product_id = ?
            `).run(product.name, id);
            database.prepare("DELETE FROM products WHERE id = ? AND seller_id = ?").run(id, req.user.id);
        });
        await removeUploadedFiles(imageUrls);
        res.json({ message: "Producto eliminado del catálogo. Los pedidos anteriores conservan su registro." });
    } catch (error) {
        if (error.status) return sendError(res, error.status, error.message);
        next(error);
    }
});

app.get("/api/cart", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const rows = database.prepare(`
            ${productSelect}
            JOIN cart_items ci ON ci.product_id = p.id
            WHERE ci.user_id = ? AND p.is_active = 1
            ORDER BY ci.rowid
        `).all(req.user.id);
        const items = rows.map(row => ({
            product: publicProduct(row),
            quantity: database.prepare("SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?").get(req.user.id, row.id).quantity
        }));
        res.json({ items });
    } catch (error) {
        next(error);
    }
});

app.post("/api/cart", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.body.productId);
        const quantity = Number(req.body.quantity);
        if (!Number.isInteger(productId) || productId < 1 || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
            return sendError(res, 400, "Selecciona un producto y una cantidad válida.");
        }
        transaction(() => {
            const product = database.prepare("SELECT id, seller_id AS sellerId, stock FROM products WHERE id = ? AND is_active = 1").get(productId);
            if (!product) throw Object.assign(new Error("Este producto ya no está disponible."), { status: 409 });
            if (product.sellerId === req.user.id) throw Object.assign(new Error("No puedes agregar tu propio producto al carrito."), { status: 400 });
            const current = database.prepare("SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?").get(req.user.id, productId);
            const nextQuantity = (current?.quantity || 0) + quantity;
            if (nextQuantity > 100) throw Object.assign(new Error("La cantidad máxima por producto es 100."), { status: 400 });
            if (nextQuantity > product.stock) throw Object.assign(new Error("No hay suficientes unidades disponibles."), { status: 409 });
            if (!current) {
                const count = database.prepare("SELECT COUNT(*) AS count FROM cart_items WHERE user_id = ?").get(req.user.id).count;
                if (count >= 50) throw Object.assign(new Error("Tu carrito puede contener hasta 50 productos distintos."), { status: 400 });
                database.prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)").run(req.user.id, productId, nextQuantity);
            } else {
                database.prepare("UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?").run(nextQuantity, req.user.id, productId);
            }
        });
        res.status(201).json({ message: "Producto agregado al carrito." });
    } catch (error) {
        if (error.status) return sendError(res, error.status, error.message);
        next(error);
    }
});

app.put("/api/cart/:productId", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.params.productId);
        const quantity = Number(req.body.quantity);
        if (!Number.isInteger(productId) || productId < 1 || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
            return sendError(res, 400, "Selecciona una cantidad válida.");
        }
        const result = database.prepare(`
            UPDATE cart_items SET quantity = ?
            WHERE user_id = ? AND product_id = ?
              AND EXISTS (SELECT 1 FROM products WHERE id = ? AND is_active = 1 AND stock >= ?)
        `).run(quantity, req.user.id, productId, productId, quantity);
        if (Number(result.changes) !== 1) return sendError(res, 409, "El producto no está disponible en esa cantidad.");
        res.json({ message: "Carrito actualizado." });
    } catch (error) {
        next(error);
    }
});

app.delete("/api/cart/:productId", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.params.productId);
        if (!Number.isInteger(productId) || productId < 1) return sendError(res, 400, "Producto inválido.");
        database.prepare("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?").run(req.user.id, productId);
        res.json({ message: "Producto eliminado del carrito." });
    } catch (error) {
        next(error);
    }
});

app.get("/api/favorites", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const rows = database.prepare(`
            ${productSelect}
            JOIN favorites f ON f.product_id = p.id
            WHERE f.user_id = ? AND p.is_active = 1
            ORDER BY f.created_at DESC
        `).all(req.user.id);
        res.json({ favorites: rows.map(row => publicProduct(row)) });
    } catch (error) {
        next(error);
    }
});

app.post("/api/favorites", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.body.productId);
        if (!Number.isInteger(productId) || productId < 1) return sendError(res, 400, "Producto inválido.");
        const product = database.prepare("SELECT id FROM products WHERE id = ? AND is_active = 1").get(productId);
        if (!product) return sendError(res, 404, "No encontramos ese producto.");
        database.prepare("INSERT OR IGNORE INTO favorites (user_id, product_id) VALUES (?, ?)").run(req.user.id, productId);
        res.status(201).json({ message: "Producto guardado en favoritos." });
    } catch (error) {
        next(error);
    }
});

app.delete("/api/favorites/:productId", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.params.productId);
        if (!Number.isInteger(productId) || productId < 1) return sendError(res, 400, "Producto inválido.");
        database.prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?").run(req.user.id, productId);
        res.json({ message: "Producto eliminado de tus favoritos." });
    } catch (error) {
        next(error);
    }
});

app.post("/api/orders", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const shippingAddress = parseShippingAddress(req.body.shippingAddress);
        const rawItems = req.body.items;
        if (!Array.isArray(rawItems) || rawItems.length < 1 || rawItems.length > 50) return sendError(res, 400, "El pedido debe contener entre 1 y 50 productos.");
        const quantities = new Map();
        for (const item of rawItems) {
            const productId = Number(item?.productId);
            const quantity = Number(item?.quantity);
            if (!Number.isInteger(productId) || productId < 1 || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
                return sendError(res, 400, "Hay productos o cantidades inválidas en el pedido.");
            }
            const combinedQuantity = (quantities.get(productId) || 0) + quantity;
            if (combinedQuantity > 100) return sendError(res, 400, "La cantidad máxima por producto es 100.");
            quantities.set(productId, combinedQuantity);
        }
        const order = transaction(() => {
            const items = [];
            let subtotalCents = 0;
            for (const [productId, quantity] of quantities) {
                const product = database.prepare(`
                    SELECT id, seller_id AS sellerId, name, price_cents AS priceCents, stock
                    FROM products WHERE id = ? AND is_active = 1
                `).get(productId);
                if (!product) throw Object.assign(new Error("Uno o más productos ya no están disponibles."), { status: 409 });
                if (product.sellerId === req.user.id) throw Object.assign(new Error("No puedes comprar tu propio producto."), { status: 400 });
                if (product.stock < quantity) throw Object.assign(new Error(`Inventario insuficiente para ${product.name}.`), { status: 409 });
                subtotalCents += product.priceCents * quantity;
                items.push({ productId, quantity, unitPriceCents: product.priceCents, name: product.name });
            }
            const taxCents = Math.round(subtotalCents * taxRatePercent / 100);
            const shippingCents = subtotalCents >= freeShippingThresholdCents ? 0 : shippingFeeCents;
            const totalCents = subtotalCents + taxCents + shippingCents;
            const created = database.prepare(`
                INSERT INTO orders (buyer_id, subtotal_cents, tax_cents, shipping_cents, total_cents, shipping_address)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run(req.user.id, subtotalCents, taxCents, shippingCents, totalCents, JSON.stringify(shippingAddress));
            const orderId = Number(created.lastInsertRowid);
            const updateStock = database.prepare(`
                UPDATE products SET stock = stock - ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                WHERE id = ? AND stock >= ? AND is_active = 1
            `);
            const addItem = database.prepare(`
                INSERT INTO order_items (order_id, product_id, quantity, unit_price_cents, product_name)
                VALUES (?, ?, ?, ?, ?)
            `);
            for (const item of items) {
                if (Number(updateStock.run(item.quantity, item.productId, item.quantity).changes) !== 1) {
                    throw Object.assign(new Error("El inventario cambió mientras procesábamos tu pedido. Inténtalo de nuevo."), { status: 409 });
                }
                addItem.run(orderId, item.productId, item.quantity, item.unitPriceCents, item.name);
            }
            const removeFromCart = database.prepare("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?");
            for (const productId of quantities.keys()) removeFromCart.run(req.user.id, productId);
            return { id: orderId, status: "PENDING", subtotalCents, taxCents, shippingCents, totalCents, shippingAddress, items };
        });
        res.status(201).json({ order: {
            id: order.id,
            status: order.status,
            subtotal: order.subtotalCents / 100,
            tax: order.taxCents / 100,
            shipping: order.shippingCents / 100,
            total: order.totalCents / 100,
            shippingAddress: order.shippingAddress,
            items: order.items.map(item => ({ name: item.name, quantity: item.quantity, price: item.unitPriceCents / 100 }))
        } });
    } catch (error) {
        if (error.status) return sendError(res, error.status, error.message);
        next(error);
    }
});

app.get("/api/orders/mine", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const rows = database.prepare(`
            WITH numbered_orders AS (
                SELECT id, ROW_NUMBER() OVER (PARTITION BY buyer_id ORDER BY created_at, id) AS buyerOrderNumber
                FROM orders
            )
            SELECT o.id, no.buyerOrderNumber, o.buyer_id AS buyerId,
                   o.status, o.subtotal_cents AS subtotalCents, o.tax_cents AS taxCents,
                   o.shipping_cents AS shippingCents, o.total_cents AS totalCents,
                   o.shipping_address AS shippingAddress, o.created_at AS createdAt,
                   COALESCE(NULLIF(oi.product_name, ''), p.name) AS productName,
                   oi.quantity, oi.unit_price_cents AS unitPriceCents
            FROM orders o
            JOIN numbered_orders no ON no.id = o.id
            LEFT JOIN order_items oi ON oi.order_id = o.id
            LEFT JOIN products p ON p.id = oi.product_id
            WHERE o.buyer_id = ? ORDER BY o.created_at DESC, oi.id
        `).all(req.user.id);
        res.json({ orders: mapOrders(rows) });
    } catch (error) {
        next(error);
    }
});

app.get("/api/admin/overview", authenticate, requireAdmin, (req, res, next) => {
    try {
        const totals = database.prepare(`
            SELECT
                (SELECT COUNT(*) FROM users u WHERE NOT EXISTS (SELECT 1 FROM site_admins a WHERE a.user_id = u.id)) AS users,
                (SELECT COUNT(*) FROM products WHERE is_active = 1) AS activeProducts,
                (SELECT COUNT(*) FROM orders) AS orders,
                (SELECT COALESCE(SUM(total_cents), 0) / 100.0 FROM orders WHERE status != 'CANCELLED') AS revenue,
                (SELECT COUNT(DISTINCT user_id) FROM auth_events WHERE datetime(occurred_at) >= datetime('now', '-1 day')) AS activeUsers24h
        `).get();
        const topProducts = database.prepare(`
            SELECT CASE
                       WHEN p.id IS NOT NULL THEN p.name || ' (#' || p.id || ')'
                       ELSE COALESCE(NULLIF(oi.product_name, ''), 'Producto eliminado') || ' (eliminado)'
                   END AS name,
                   SUM(oi.quantity) AS unitsSold,
                   SUM(oi.quantity * oi.unit_price_cents) / 100.0 AS revenue
            FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id
            JOIN orders o ON o.id = oi.order_id
            WHERE o.status != 'CANCELLED'
            GROUP BY CASE
                         WHEN p.id IS NOT NULL THEN 'product:' || p.id
                         ELSE 'snapshot:' || COALESCE(NULLIF(oi.product_name, ''), 'Producto eliminado')
                     END
            ORDER BY unitsSold DESC, revenue DESC LIMIT 8
        `).all();
        const topBuyers = database.prepare(`
            SELECT u.id, u.name, u.email, COUNT(DISTINCT o.id) AS orders,
                   COALESCE(SUM(oi.quantity), 0) AS unitsBought,
                   COALESCE(SUM(oi.quantity * oi.unit_price_cents), 0) / 100.0 AS spent
            FROM orders o JOIN users u ON u.id = o.buyer_id
            LEFT JOIN order_items oi ON oi.order_id = o.id
            WHERE o.status != 'CANCELLED'
              AND NOT EXISTS (SELECT 1 FROM site_admins a WHERE a.user_id = u.id)
            GROUP BY u.id ORDER BY spent DESC, orders DESC LIMIT 8
        `).all();
        const dailySignIns = database.prepare(`
            SELECT strftime('%Y-%m-%d', occurred_at) AS date, COUNT(DISTINCT user_id) AS users
            FROM auth_events WHERE datetime(occurred_at) >= datetime('now', '-6 days')
            GROUP BY date ORDER BY date
        `).all();
        res.json({ totals, topProducts, topBuyers, dailySignIns });
    } catch (error) {
        next(error);
    }
});

app.get("/api/admin/schema", authenticate, requireAdmin, (req, res, next) => {
    try {
        const tables = database.prepare(`
            SELECT name, sql FROM sqlite_master
            WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        `).all().map(table => {
            const escapedName = table.name.replace(/"/g, '""');
            return {
                name: table.name,
                definition: table.sql,
                columns: database.prepare(`PRAGMA table_info("${escapedName}")`).all(),
                foreignKeys: database.prepare(`PRAGMA foreign_key_list("${escapedName}")`).all(),
                indexes: database.prepare(`PRAGMA index_list("${escapedName}")`).all()
            };
        });
        res.json({ tables });
    } catch (error) {
        next(error);
    }
});

app.get("/api/admin/users", authenticate, requireAdmin, (req, res, next) => {
    try {
        const users = database.prepare(`
            SELECT u.id, u.name, u.email, u.role, u.created_at AS createdAt,
                   (SELECT COUNT(*) FROM products p WHERE p.seller_id = u.id) AS productCount,
                   (SELECT COUNT(*) FROM orders o WHERE o.buyer_id = u.id) AS orderCount
            FROM users u ORDER BY u.created_at DESC, u.id DESC
        `).all().map(user => ({ ...user, role: safeUser({ ...user, created_at: user.createdAt }).role }));
        res.json({ users });
    } catch (error) {
        next(error);
    }
});

app.put("/api/admin/users/:id", authenticate, requireAdmin, (req, res, next) => {
    try {
        const userId = Number(req.params.id);
        if (!Number.isInteger(userId) || userId < 1) return sendError(res, 400, "Usuario inválido.");
        if (database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(userId)) {
            return sendError(res, 403, "La cuenta de administración no se puede modificar desde el listado de usuarios.");
        }
        const user = database.prepare("SELECT id, name, role FROM users WHERE id = ?").get(userId);
        if (!user) return sendError(res, 404, "No encontramos ese usuario.");
        const name = req.body.name === undefined ? user.name : (typeof req.body.name === "string" ? req.body.name.trim() : "");
        const role = req.body.role === undefined ? user.role : req.body.role;
        if (name.length < 2 || name.length > 80) return sendError(res, 400, "El nombre debe tener entre 2 y 80 caracteres.");
        if (!allowedRoles.has(role)) return sendError(res, 400, "El perfil seleccionado no es válido.");
        database.prepare("UPDATE users SET name = ?, role = ? WHERE id = ?").run(name, role, userId);
        res.json({ message: "Usuario actualizado.", user: safeUser(findUserById(userId)) });
    } catch (error) {
        next(error);
    }
});

app.put("/api/admin/users/:id/password", authenticate, requireAdmin, async (req, res, next) => {
    try {
        const userId = Number(req.params.id);
        const password = typeof req.body.password === "string" ? req.body.password : "";
        if (!Number.isInteger(userId) || userId < 1) return sendError(res, 400, "Usuario inválido.");
        if (password.length < 8 || password.length > 72) return sendError(res, 400, "La contraseña debe tener entre 8 y 72 caracteres.");
        const user = database.prepare("SELECT id FROM users WHERE id = ?").get(userId);
        if (!user) return sendError(res, 404, "No encontramos ese usuario.");
        if (database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(userId)) return sendError(res, 403, "La contraseña admin se cambia desde su cuenta.");
        const passwordHash = await bcrypt.hash(password, 12);
        database.prepare("UPDATE users SET password_hash = ?, session_version = session_version + 1 WHERE id = ?").run(passwordHash, userId);
        res.json({ message: "Contraseña actualizada. Las sesiones abiertas de este usuario quedaron invalidadas." });
    } catch (error) {
        next(error);
    }
});

async function removeUserAccountData(userId) {
    const imageUrls = database.prepare(`
        SELECT pi.url FROM product_images pi
        JOIN products p ON p.id = pi.product_id
        WHERE p.seller_id = ?
        UNION
        SELECT ri.url FROM review_images ri
        JOIN reviews r ON r.id = ri.review_id
        LEFT JOIN products p ON p.id = r.product_id
        WHERE r.user_id = ? OR p.seller_id = ?
    `).all(userId, userId, userId).map(image => image.url);
    transaction(() => {
        database.prepare(`
            UPDATE order_items
            SET product_name = COALESCE(NULLIF(product_name, ''), (
                SELECT name FROM products WHERE products.id = order_items.product_id
            )), product_id = NULL
            WHERE product_id IN (SELECT id FROM products WHERE seller_id = ?)
        `).run(userId);
        database.prepare("UPDATE orders SET buyer_id = NULL, shipping_address = NULL WHERE buyer_id = ?").run(userId);
        database.prepare("DELETE FROM reviews WHERE user_id = ?").run(userId);
        database.prepare("DELETE FROM products WHERE seller_id = ?").run(userId);
        database.prepare("DELETE FROM users WHERE id = ?").run(userId);
    });
    await removeUploadedFiles(imageUrls);
}

app.delete("/api/admin/users/:id", authenticate, requireAdmin, async (req, res, next) => {
    try {
        const userId = Number(req.params.id);
        if (!Number.isInteger(userId) || userId < 1) return sendError(res, 400, "Usuario inválido.");
        if (userId === req.user.id || database.prepare("SELECT 1 FROM site_admins WHERE user_id = ?").get(userId)) {
            return sendError(res, 403, "No puedes eliminar la cuenta admin activa.");
        }
        if (!database.prepare("SELECT id FROM users WHERE id = ?").get(userId)) return sendError(res, 404, "No encontramos ese usuario.");
        await removeUserAccountData(userId);
        res.json({ message: "Usuario eliminado. Los pedidos anteriores se conservaron anonimizados." });
    } catch (error) {
        next(error);
    }
});

app.get("/api/admin/products", authenticate, requireAdmin, (req, res, next) => {
    try {
        const products = database.prepare(`${productSelect} ORDER BY p.created_at DESC, p.id DESC`).all();
        res.json({ products: products.map(product => ({
            ...publicProduct(product, database.prepare("SELECT url FROM product_images WHERE product_id = ? ORDER BY id").all(product.id).map(image => image.url)),
            sellerId: product.sellerId,
            sellerName: product.sellerName,
            isActive: Boolean(product.isActive),
            createdAt: product.createdAt
        })) });
    } catch (error) {
        next(error);
    }
});

app.delete("/api/admin/products/:id", authenticate, requireAdmin, async (req, res, next) => {
    try {
        const productId = Number(req.params.id);
        if (!Number.isInteger(productId) || productId < 1) return sendError(res, 400, "Producto inválido.");
        const product = database.prepare("SELECT id, name FROM products WHERE id = ?").get(productId);
        if (!product) return sendError(res, 404, "No encontramos ese producto.");
        const imageUrls = [
            ...database.prepare("SELECT url FROM product_images WHERE product_id = ?").all(productId).map(image => image.url),
            ...database.prepare("SELECT ri.url FROM review_images ri JOIN reviews r ON r.id = ri.review_id WHERE r.product_id = ?").all(productId).map(image => image.url)
        ];
        transaction(() => {
            database.prepare(`
                UPDATE order_items SET product_name = COALESCE(NULLIF(product_name, ''), ?), product_id = NULL
                WHERE product_id = ?
            `).run(product.name, productId);
            database.prepare("DELETE FROM products WHERE id = ?").run(productId);
        });
        await removeUploadedFiles(imageUrls);
        res.json({ message: "Producto eliminado. Los pedidos previos conservan su snapshot." });
    } catch (error) {
        next(error);
    }
});

app.get("/api/admin/orders", authenticate, requireAdmin, (req, res, next) => {
    try {
        const rows = database.prepare(`
            WITH numbered_orders AS (
                SELECT id, ROW_NUMBER() OVER (PARTITION BY buyer_id ORDER BY created_at, id) AS buyerOrderNumber
                FROM orders
            )
            SELECT o.id, no.buyerOrderNumber, o.buyer_id AS buyerId, u.name AS buyerName, u.email AS buyerEmail,
                   o.status, o.subtotal_cents AS subtotalCents, o.tax_cents AS taxCents,
                   o.shipping_cents AS shippingCents, o.total_cents AS totalCents,
                   o.shipping_address AS shippingAddress, o.created_at AS createdAt,
                   COALESCE(NULLIF(oi.product_name, ''), p.name) AS productName,
                   oi.quantity, oi.unit_price_cents AS unitPriceCents
            FROM orders o JOIN numbered_orders no ON no.id = o.id
            LEFT JOIN users u ON u.id = o.buyer_id
            LEFT JOIN order_items oi ON oi.order_id = o.id
            LEFT JOIN products p ON p.id = oi.product_id
            ORDER BY o.created_at DESC, oi.id
        `).all();
        res.json({ orders: mapOrders(rows) });
    } catch (error) {
        next(error);
    }
});

app.put("/api/admin/orders/:id", authenticate, requireAdmin, (req, res, next) => {
    try {
        const orderId = Number(req.params.id);
        const allowedStatuses = new Set(["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"]);
        const status = typeof req.body.status === "string" ? req.body.status : "";
        if (!Number.isInteger(orderId) || orderId < 1) return sendError(res, 400, "Pedido inválido.");
        if (!allowedStatuses.has(status)) return sendError(res, 400, "El estado del pedido no es válido.");
        const result = database.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, orderId);
        if (Number(result.changes) !== 1) return sendError(res, 404, "No encontramos ese pedido.");
        res.json({ message: "Estado del pedido actualizado." });
    } catch (error) {
        next(error);
    }
});

function getReview(reviewId) {
    const review = database.prepare(`
        SELECT r.id, r.product_id AS productId, r.user_id AS userId, r.rating, r.comment,
               r.created_at AS createdAt, u.name AS buyerName
        FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.id = ?
    `).get(reviewId);
    if (review) {
        review.images = database.prepare("SELECT url FROM review_images WHERE review_id = ? ORDER BY id").all(reviewId).map(image => image.url);
    }
    return review;
}

function parseReviewInput(body) {
    const rating = Number(body.rating);
    const comment = typeof body.comment === "string" ? body.comment.trim() : "";
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw Object.assign(new Error("La calificación debe ser de 1 a 5 estrellas."), { status: 400 });
    if (comment.length < 5 || comment.length > 1000) throw Object.assign(new Error("La reseña debe tener entre 5 y 1000 caracteres."), { status: 400 });
    return { rating, comment };
}

function hasProductPurchase(productId, userId) {
    return Boolean(database.prepare(`
        SELECT oi.id FROM order_items oi JOIN orders o ON o.id = oi.order_id
        WHERE oi.product_id = ? AND o.buyer_id = ? LIMIT 1
    `).get(productId, userId));
}

app.get("/api/products/:id/reviews/mine", authenticate, requireRole("BUYER", "BOTH"), (req, res, next) => {
    try {
        const productId = Number(req.params.id);
        if (!Number.isInteger(productId) || productId < 1) return sendError(res, 400, "Producto inválido.");
        const review = database.prepare("SELECT id FROM reviews WHERE product_id = ? AND user_id = ?").get(productId, req.user.id);
        res.json({ review: review ? getReview(review.id) : null, canReview: hasProductPurchase(productId, req.user.id) });
    } catch (error) {
        next(error);
    }
});

app.post("/api/products/:id/reviews", authenticate, requireRole("BUYER", "BOTH"), upload.array("reviewImages", 3), async (req, res, next) => {
    const files = req.files || [];
    let persisted = false;
    try {
        const productId = Number(req.params.id);
        if (!Number.isInteger(productId) || productId < 1) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 400, "Producto inválido.");
        }
        if (!database.prepare("SELECT id FROM products WHERE id = ? AND is_active = 1").get(productId)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 404, "No encontramos ese producto.");
        }
        const { rating, comment } = parseReviewInput(req.body);
        if (!hasProductPurchase(productId, req.user.id)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 403, "Solo puedes reseñar productos que hayas comprado.");
        }
        const validImages = await Promise.all(files.map(isValidImage));
        if (validImages.some(isValid => !isValid)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 400, "Una o más fotos no contienen una imagen JPG, PNG o WebP válida.");
        }
        const reviewId = transaction(() => {
            const result = database.prepare("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)").run(productId, req.user.id, rating, comment);
            const id = Number(result.lastInsertRowid);
            const insertImage = database.prepare("INSERT INTO review_images (review_id, url) VALUES (?, ?)");
            files.forEach(file => insertImage.run(id, `/uploads/${path.basename(file.path)}`));
            return id;
        });
        persisted = true;
        res.status(201).json({ review: getReview(reviewId) });
    } catch (error) {
        if (!persisted) await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
        if (error.errcode === 2067 || error.message.includes("UNIQUE constraint failed: reviews.product_id, reviews.user_id")) {
            return sendError(res, 409, "Ya publicaste una reseña para este producto. Puedes editarla.");
        }
        if (error.status) return sendError(res, error.status, error.message);
        next(error);
    }
});

app.put("/api/products/:id/reviews/:reviewId", authenticate, requireRole("BUYER", "BOTH"), upload.array("reviewImages", 3), async (req, res, next) => {
    const files = req.files || [];
    let persisted = false;
    try {
        const productId = Number(req.params.id);
        const reviewId = Number(req.params.reviewId);
        if (!Number.isInteger(productId) || productId < 1 || !Number.isInteger(reviewId) || reviewId < 1) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 400, "Reseña inválida.");
        }
        const current = database.prepare("SELECT id FROM reviews WHERE id = ? AND product_id = ? AND user_id = ?").get(reviewId, productId, req.user.id);
        if (!current) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 404, "No encontramos una reseña tuya para este producto.");
        }
        const { rating, comment } = parseReviewInput(req.body);
        if (!hasProductPurchase(productId, req.user.id)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 403, "Solo puedes editar reseñas de productos que hayas comprado.");
        }
        const validImages = await Promise.all(files.map(isValidImage));
        if (validImages.some(isValid => !isValid)) {
            await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
            return sendError(res, 400, "Una o más fotos no contienen una imagen JPG, PNG o WebP válida.");
        }
        const removeImages = req.body.removeImages === "true";
        const oldImages = (files.length || removeImages)
            ? database.prepare("SELECT url FROM review_images WHERE review_id = ?").all(reviewId).map(image => image.url)
            : [];
        transaction(() => {
            database.prepare("UPDATE reviews SET rating = ?, comment = ? WHERE id = ? AND user_id = ?").run(rating, comment, reviewId, req.user.id);
            if (files.length || removeImages) {
                database.prepare("DELETE FROM review_images WHERE review_id = ?").run(reviewId);
                const insertImage = database.prepare("INSERT INTO review_images (review_id, url) VALUES (?, ?)");
                files.forEach(file => insertImage.run(reviewId, `/uploads/${path.basename(file.path)}`));
            }
        });
        persisted = true;
        await removeUploadedFiles(oldImages);
        res.json({ review: getReview(reviewId) });
    } catch (error) {
        if (!persisted) await Promise.all(files.map(file => fs.promises.rm(file.path, { force: true })));
        if (error.status) return sendError(res, error.status, error.message);
        next(error);
    }
});

app.delete("/api/products/:id/reviews/:reviewId", authenticate, requireRole("BUYER", "BOTH"), async (req, res, next) => {
    try {
        const productId = Number(req.params.id);
        const reviewId = Number(req.params.reviewId);
        if (!Number.isInteger(productId) || productId < 1 || !Number.isInteger(reviewId) || reviewId < 1) return sendError(res, 400, "Reseña inválida.");
        const imageUrls = database.prepare("SELECT url FROM review_images WHERE review_id = ?").all(reviewId).map(image => image.url);
        const result = database.prepare("DELETE FROM reviews WHERE id = ? AND product_id = ? AND user_id = ?").run(reviewId, productId, req.user.id);
        if (Number(result.changes) !== 1) return sendError(res, 404, "No encontramos una reseña tuya para este producto.");
        await removeUploadedFiles(imageUrls);
        res.json({ message: "Tu reseña fue eliminada." });
    } catch (error) {
        next(error);
    }
});

app.use((req, res, next) => {
    let staticPath;
    try {
        staticPath = req.path;
        for (let attempt = 0; attempt < 5; attempt += 1) {
            const decoded = decodeURIComponent(staticPath);
            if (decoded === staticPath) break;
            staticPath = decoded;
        }
    } catch {
        return sendError(res, 400, "La ruta solicitada no es válida.");
    }
    if (/%[0-9a-f]{2}/i.test(staticPath)) return sendError(res, 400, "La ruta solicitada no es válida.");
    staticPath = path.posix.normalize(`/${staticPath.replace(/\\/g, "/").replace(/^\/+/, "")}`).toLowerCase();
    if (/^\/(?:server|node_modules|\.git|\.parcel-cache)(?:\/|$)/.test(staticPath)) {
        return sendError(res, 404, "No encontrado.");
    }
    next();
});
app.use(express.static(webRoot, { dotfiles: "deny", index: "index.html", maxAge: process.env.NODE_ENV === "production" ? "1h" : 0 }));
app.use((error, _req, res, _next) => {
    if (error instanceof multer.MulterError) return sendError(res, 400, error.code === "LIMIT_FILE_SIZE" ? "Cada imagen debe pesar 5 MB o menos." : "No se pudieron procesar las imágenes.");
    if (error.message === "Solo se aceptan imágenes JPG, PNG o WebP.") return sendError(res, 400, error.message);
    if (error.status && error.status < 500) return sendError(res, error.status, error.type === "entity.too.large" ? "La solicitud supera el tamaño permitido." : error.message);
    console.error(error);
    return sendError(res, 500, "Ocurrió un error interno. Inténtalo de nuevo.");
});

const server = app.listen(port, () => console.log(`MotorCrew listo en http://localhost:${port}`));

for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => {
        server.close(() => {
            database.close();
            process.exit(0);
        });
    });
}
