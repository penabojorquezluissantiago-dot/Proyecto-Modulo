MOTORCREW | Tienda de autopartes

REQUISITOS
- Node.js 24 o posterior y npm.

INICIO LOCAL
1. Abre una terminal en la carpeta server.
2. Ejecuta: npm install
3. Copia .env.example como .env y configura JWT_SECRET con una cadena aleatoria de al menos 32 caracteres.
4. Para habilitar la cuenta administradora main@motorcrew.admin, define ADMIN_INITIAL_PASSWORD en server/.env con una contraseña privada de al menos 12 caracteres. La contraseña no está fijada en el código y la cuenta no se aprovisiona hasta establecer esa variable.
5. Ejecuta: npm run dev
6. Abre http://localhost:3000

CUENTA DE ADMINISTRADOR
Correo: main@motorcrew.admin
Contraseña Inicial: lnvmdP0Orwtf3e2UNu7SwiZHsHY8oq1N

La base de datos SQLite se crea automáticamente en server/data/motorcrew.sqlite. Las imágenes se guardan en server/uploads.
No se incluyen productos de muestra: los artículos aparecen en el catálogo al ser publicados por un vendedor.

FUNCIONES
- Registro e inicio de sesión con perfiles comprador, vendedor o comprador/vendedor.
- Carrito y favoritos asociados a la cuenta del comprador.
- Publicación de productos con categoría, precio, existencias y hasta cinco fotos.
- Catálogo con búsqueda, filtros y ficha pública de cada producto.
- Pedidos con dirección de entrega, inventario y totales calculados en el servidor.
- El resumen aplica IVA del 16% y envío de $149 MXN; el envío es gratis desde $1,500 MXN en productos.
- Perfil del comprador con favoritos e historial de pedidos.
- Páginas separadas para compras, favoritos y configuración de la cuenta.
- Configuración para cambiar nombre de usuario y contraseña; el cambio de contraseña invalida las demás sesiones.
- Selector para cambiar entre sesiones iniciadas en el mismo navegador; las credenciales no se guardan en el almacenamiento local.
- Eliminación permanente de cuentas con datos personales anonimizados en pedidos previos.
- Eliminación de productos por su vendedor, conservando el detalle de ventas anteriores.
- Reseñas de una por comprador y producto, únicamente tras una compra registrada.
- Los compradores pueden editar o eliminar su reseña, calificar con estrellas y adjuntar hasta tres fotos.
- Botón para visitar la tienda desde la introducción de la galería.
- Panel de administración privado: métricas y tendencias, gestión de usuarios/productos/pedidos y consulta de la estructura de las tablas SQLite. Los datos de actividad se registran desde que se habilitó esa medición.

Los pedidos quedan registrados, pero esta versión no procesa pagos ni coordina envíos automáticamente; el comprador y el vendedor acuerdan esos detalles. Para producción, configura HTTPS, una clave JWT segura, copias de seguridad de SQLite y un servicio de almacenamiento de imágenes.